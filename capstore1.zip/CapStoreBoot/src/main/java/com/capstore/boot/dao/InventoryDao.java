package com.capstore.boot.dao;

import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Inventory;

@Repository("inventoryDao")

@Transactional
public interface InventoryDao extends JpaRepository<Inventory, Integer>{
	
	@Query("select i from Inventory i where i.productName=:product")
	Inventory findOne(@Param("product") String product);
	
}
