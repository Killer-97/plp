package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Customer;



public interface ICustomerService {

	public List<Customer> getAllCustomerEmail();
	
	Customer findOne(Integer customerId);

	List<Customer> getAllCustomer();
	public List<Customer> getAllCustomers();


}
