package com.capstore.boot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.IPasswordDao;
import com.capstore.boot.model.Customer;

@Service("passwordService")
public class PasswordServiceImpl implements IPasswordService {

	@Autowired 
	 IPasswordDao passwordDao;
	
	@Override
	public List<Customer> getAllCustomers() {
	  return passwordDao.findAll();	
	}

}
