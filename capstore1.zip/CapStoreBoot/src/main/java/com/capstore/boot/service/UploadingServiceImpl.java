package com.capstore.boot.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.CustomerInterface;
import com.capstore.boot.dao.EmailInterface;
import com.capstore.boot.dao.UploadImageInterface;
import com.capstore.boot.model.Attraction;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Email;





@Service("pilotDBService")
public class UploadingServiceImpl implements UploadingServiceInterface {
	@Autowired
	private UploadImageInterface uploadImageDBdao;
	
	@Autowired
	private CustomerInterface customerDBdao;
	
	@Autowired
	private EmailInterface emailDBdao;
	/*@Override
	public List<UploadImage> getAllImage() {
		// TODO Auto-generated method stub
		return uploadImageDBdao.findAll();
	}*/
	/**
	 * Method Name : getMaxId
	 * Return Type : int
	
	 */
	
	@Override
	public int getMaxId() {
		// TODO Auto-generated method stub
		return uploadImageDBdao.findMaxProductId();
	}
	
	
	/**
	 * Method Name : save
	 * Return Type : void
	 

	 * Purpose     : To save the Attraction in Attraction Table
	 */
	
	@Override
	public void save(Attraction product) {
		// TODO Auto-generated method stub
		uploadImageDBdao.save(product);
	}
	
	/**
	 * Method Name : getAllProducts
	 * Return Type : List of Attraction
	
	 
	 * Purpose     : To get All the Product from Attraction
	 */
	
	@Override
	public List<Attraction> getAllProducts() {
		// TODO Auto-generated method stub
		return uploadImageDBdao.findAll();
	}
	
	
	/**
	 * Method Name : getAllCustomer
	 * Return Type : List of Customer
	
	 * Purpose     : To get All the Customer 
	 */
	
	@Override
	public List<Customer> getAllCustomer(Date d) {
		// TODO Auto-generated method stub
		return customerDBdao.findByDate(d);
	}
	
	/**
	 * Method Name : findAttraction
	 * Return Type : Attraction
	
	
	 * Purpose     : To find the attraction with a given id 
	 */
	
	@Override
	public Attraction findAttraction(Integer id) {
		// TODO Auto-generated method stub
		return uploadImageDBdao.getOne(id);
	}
	
	/**
	 * Method Name : saveMail
	 * Return Type : void

	 * Purpose     : To send mail to customer 
	 */
	@Override
	public void saveMail(Email email) {
		// TODO Auto-generated method stub
		emailDBdao.save(email);
	}
	
		


}
