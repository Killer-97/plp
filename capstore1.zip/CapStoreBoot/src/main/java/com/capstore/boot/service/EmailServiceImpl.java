package com.capstore.boot.service;

import java.util.List;

//import org.capstore.boot.dao.EmailDao;
//import org.capstore.boot.model.Customer;
//import org.capstore.boot.model.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.EmailDao;
import com.capstore.boot.model.Email;

@Service("emailService")
public class EmailServiceImpl implements IEmailService{

	@Autowired
	EmailDao emailDao;
	
	@Override
	public List<Email> getAll() {
		
		return emailDao.findAll();
	}

	@Override
	public void save(Email email) {
		
		emailDao.save(email);
		
	}

}
