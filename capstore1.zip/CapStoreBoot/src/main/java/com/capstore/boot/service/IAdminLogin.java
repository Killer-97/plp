package com.capstore.boot.service;

import com.capstore.boot.model.Admin;

public interface IAdminLogin {

	public Admin getAdmin(String username, String password);
}
