package com.capstore.boot.dao;


import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Attraction;




@Repository("uploadImageDBdao")
@Transactional
public interface UploadImageInterface extends JpaRepository<Attraction, Integer>{
	
	/**
	 * Method Name : findMaxProductId
	 * Return Type : Max product id
	 * Author      : Shubhendu Mal
	 * Date        : 20 Aug,2018
	 */
	
	
	
	@Query("select max(attractionId) from Attraction")
	public Integer findMaxProductId();
}
