package com.capstore.boot.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.IAddressDao;
import com.capstore.boot.dao.ICustomerDao;
import com.capstore.boot.dao.IEmailDao;
import com.capstore.boot.dao.IOrderDao;
import com.capstore.boot.dao.IShippingDao;
import com.capstore.boot.model.Address;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Email;
import com.capstore.boot.model.Order;
import com.capstore.boot.model.Shipping;
@Service("shippingService")
public class ShippingServiceImpl implements IShippingService {
	@Autowired(required=true)
    IAddressDao addressDao;
	@Autowired(required=true)
	private IShippingDao shippingDao;
	@Autowired(required=true)
    IEmailDao emailDao;
	@Autowired(required=true)
	private ICustomerDao customerDao;
	@Autowired(required=true)
	private IOrderDao orderDao;

	@Override
	public List<Address> findAll(Integer custId) {
		List<Address> address=addressDao.findAddress(custId);
		return address;
	}


	@Override
	public void addAddress(Address address) {
		addressDao.save(address);
		
	}


	@Override
	public void addShipping(Shipping shipping) {
		shippingDao.save(shipping);
		
	}


	@Override
	public List<Shipping> getShipping() {
		return shippingDao.findAll();
	}


	@Override
	public void addEmail(Email email) {
		emailDao.save(email);
		
	}


	@Override
	public List<Email> getEmail() {
		return emailDao.findAll();
		
	}


	@Override
	public Customer findCustomer(Integer custId) {
		return customerDao.getOne(custId);
	}


	@Override
	public Order findOrder(Integer orderId) {
		return orderDao.getOne(orderId);
	}
	
}
