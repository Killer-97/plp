package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Merchant;






public interface IRegMerchantService {

	public void saveMerchant(Merchant merchant);
	public List<Merchant> getAllMerchants();
	public Merchant getValidMerchant(String username, String password);
}
