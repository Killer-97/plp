package com.capstore.boot.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Component
public class ForgotPassword {
	@Id
	@GeneratedValue(generator="cust1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust1",sequenceName="ForgotPassword1",initialValue=1,allocationSize=1)
private int fID;
private String emailId;
private String link;
private Date date;
private boolean isAccessed;
public ForgotPassword() {
	
}



public int getfID() {
	return fID;
}



public void setfID(int fID) {
	this.fID = fID;
}



public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public String getLink() {
	return link;
}

public void setLink(String link) {
	this.link = link;
}

public Date getDate() {
	return date;
}

public void setDate(Date date) {
	this.date = date;
}

public boolean isAccessed() {
	return isAccessed;
}

public void setAccessed(boolean isAccessed) {
	this.isAccessed = isAccessed;
}



public ForgotPassword(int fID, String emailId, String link, Date date, boolean isAccessed) {
	super();
	this.fID = fID;
	this.emailId = emailId;
	this.link = link;
	this.date = date;
	this.isAccessed = isAccessed;
}




}
