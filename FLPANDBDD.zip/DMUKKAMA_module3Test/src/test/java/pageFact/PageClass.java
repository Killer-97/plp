package pageFact;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PageClass {

	WebDriver driver;

	public PageClass(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "txtName")
	@CacheLookup
	WebElement applicantName;

	public void setApplicantName(String name) {
		applicantName.sendKeys(name);
	}

	@FindBy(id = "txtFirstName")
	@CacheLookup
	WebElement firstName;

	public void setFirstName(String name) {
		firstName.sendKeys(name);
	}

	@FindBy(id = "txtLastName")
	@CacheLookup
	WebElement lastName;

	public void setLastName(String name) {
		lastName.sendKeys(name);
	}

	@FindBy(how = How.NAME, using = "txtFtName")
	@CacheLookup
	WebElement fatherName;

	public void setFatherName(String name) {
		fatherName.sendKeys(name);
	}

	@FindBy(how = How.NAME, using = "txtDOB")
	@CacheLookup
	WebElement dob;

	public void setDOB(String name) {
		dob.sendKeys(name);
	}

	@FindBy(id = "rdbMale")
	@CacheLookup
	WebElement male;

	public void clickMale() {
		male.click();
	}

	@FindBy(id = "rdbFemale")
	@CacheLookup
	WebElement female;

	public void clickFemale() {
		female.click();
	}

	@FindBy(how = How.XPATH, using = "//*[@id=\"txtMobileNo\"]")
	@CacheLookup
	WebElement mobile;

	public void setMobile(String number) {
		mobile.sendKeys(number);
	}

	@FindBy(how = How.CSS, using = "#txtEmail")
	@CacheLookup
	WebElement email;

	public void setEMail(String mail) {
		email.sendKeys(mail);
	}

	@FindBy(id = "txtLndLine")
	@CacheLookup
	WebElement landline;

	public void setLandline(String no) {
		landline.sendKeys(no);
	}

	@FindBy(id = "rdbResAddress")
	@CacheLookup
	WebElement resident;

	public void clickResident() {
		resident.click();
	}

	@FindBy(id = "rdbOfficeAdd")
	@CacheLookup
	WebElement office;

	public void clickOffice() {
		office.click();
	}

	@FindBy(id = "txtAResidenceAdd")
	@CacheLookup
	WebElement resaddress;

	public void setResidentaddress(String addr) {
		resaddress.sendKeys(addr);
	}

	@FindBy(id = "btnSubmit")
	@CacheLookup
	WebElement submit;

	public void Submit() {
		submit.click();
	}


	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement holder;

	public void setCardHolder(String name) {
		holder.sendKeys(name);
	}

	@FindBy(id = "txtDebit")
	@CacheLookup
	WebElement debit;

	public void setDebit(String name) {
		debit.sendKeys(name);
	}

	@FindBy(id = "txtMonth")
	@CacheLookup
	WebElement month;

	public void setMonth(String name) {
		month.sendKeys(name);
	}

	@FindBy(id = "txtYear")
	@CacheLookup
	WebElement year;

	public void setYear(String name) {
		year.sendKeys(name);
	}

	@FindBy(id = "btnPayment")
	@CacheLookup
	WebElement mbutton;

	public void clickMbutton() {
		mbutton.click();
	}
	
	@FindBy(id = "txtCvv")
	@CacheLookup
	WebElement cvv;

	public void setCvv(String CC) {
		cvv.sendKeys(CC);
	}
	
	
	

}
