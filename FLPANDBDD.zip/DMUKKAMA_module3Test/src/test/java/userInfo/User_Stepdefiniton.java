package userInfo;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageFact.PageClass;

public class User_Stepdefiniton {
	
	WebDriver driver;
	PageClass pg;

	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "c:\\Selenium Lib\\chromedriver.exe");
		driver = new ChromeDriver();
		pg = new PageClass(driver);
	
	}
	

@Given("^customer is on userinformation page$")
public void customer_is_on_userinformation_page() throws Throwable {
	 driver.get("file:///C:/Users/DMUKKAMA/Desktop/applications/module3exam/UserInformation.html");
}

@When("^customer sees the title of the page$")
public void customer_sees_the_title_of_the_page() throws Throwable {
   String expected_title=driver.getTitle();
   System.out.println(expected_title);
   
}

@Then("^the title should be \"([^\"]*)\"$")
public void the_title_should_be(String arg1) throws Throwable {
	String expected_title=driver.getTitle();
	 if(expected_title.contentEquals(arg1)) {
		 System.out.println("title is same");
	 }else {
		 System.out.println("title mismatch");
	 }
	 driver.close();
}
@When("^customer didnot gave applicant name$")
public void customer_didnot_gave_applicant_name() throws Throwable {
	pg.setApplicantName("");
    
}

@When("^clicks on Submit button$")
public void clicks_on_Submit_button() throws Throwable {
   pg.Submit();
}

@Then("^a popup should be diplayed to fill applicant name$")
public void a_popup_should_be_diplayed_to_fill_applicant_name() throws Throwable {
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer didnot gave first name$")
public void customer_didnot_gave_first_name() throws Throwable {
	pg.setApplicantName("Damu");
	   pg.setFirstName("");
  
}

@Then("^a popup should be diplayed to fill first name$")
public void a_popup_should_be_diplayed_to_fill_first_name() throws Throwable {
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer didnot gave last name$")
public void customer_didnot_gave_last_name() throws Throwable {
	  pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("");
    
}

@Then("^a popup should be diplayed to fill last name$")
public void a_popup_should_be_diplayed_to_fill_last_name() throws Throwable {
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer didnot gave father name$")
public void customer_didnot_gave_father_name() throws Throwable {
	  pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("");
}

@Then("^a popup should be diplayed to fill father name$")
public void a_popup_should_be_diplayed_to_fill_father_name() throws Throwable {
	
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer didnot gave date of birth$")
public void customer_didnot_gave_date_of_birth() throws Throwable {
	  pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
}

@Then("^a popup should be diplayed to fill date of birth$")
public void a_popup_should_be_diplayed_to_fill_date_of_birth() throws Throwable {
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer gave invalid date of bith format$")
public void customer_gave_invalid_date_of_bith_format() throws Throwable {
	pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
	   pg.setDOB("12/36/234344");
}

@Then("^an alert should be diplayed with invalid date of birth$")
public void an_alert_should_be_diplayed_with_invalid_date_of_birth() throws Throwable {
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer didnotselect gender$")
public void customer_didnotselect_gender() throws Throwable {
	pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
	   pg.setDOB("16-06-1998");
   
}

@Then("^an alert should be diplayed with \"([^\"]*)\"$")
public void an_alert_should_be_diplayed_with(String arg1) throws Throwable {
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer didnot gave mobile no$")
public void customer_didnot_gave_mobile_no() throws Throwable {
	pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
	   pg.setDOB("16-06-1998");
	   pg.clickMale();
}

@Then("^a popup should be diplayed with \"([^\"]*)\"$")
public void a_popup_should_be_diplayed_with(String arg1) throws Throwable {
	Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	driver.close();
}

@When("^customer  gave  invalid mobile no$")
public void customer_gave_invalid_mobile_no() throws Throwable {
	pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
	   pg.setDOB("16-06-1998");
	   pg.clickMale();
	   pg.setMobile("654756478676");
}

@When("^customer didnot gave email$")
public void customer_didnot_gave_email() throws Throwable {
	 pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
	   pg.setDOB("16-06-1998");
	   pg.clickMale();
	   pg.setMobile("7412589637");
}

@When("^customer didnot gave landline$")
public void customer_didnot_gave_landline() throws Throwable {
	 pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
	   pg.setDOB("16-06-1998");
	   pg.clickMale();
	   pg.setMobile("7412589637");
	   pg.setEMail("abc@email.com");
}

@When("^customer didnot selectradion button of communicationo$")
public void customer_didnot_selectradion_button_of_communicationo() throws Throwable {
	 pg.setApplicantName("Damu");
	   pg.setFirstName("Damodhar");
	   pg.setLastName("Mukkamala");
	   pg.setFatherName("BVVS");
	   pg.setDOB("16-06-1998");
	   pg.clickMale();
	   pg.setMobile("7412589637");
	   pg.setEMail("abc@email.com");
	   pg.setLandline("741258");
}

@When("^customer gives valid details in the form$")
public void customer_gives_valid_details_in_the_form() throws Throwable {
   pg.setApplicantName("Damu");
   pg.setFirstName("Damodhar");
   pg.setLastName("Mukkamala");
   pg.setFatherName("BVVS");
   pg.setDOB("16-06-1998");
   pg.clickMale();
   pg.setMobile("7412589637");
   pg.setEMail("abc@email.com");
   pg.setLandline("741258");
   pg.clickOffice();
   pg.setResidentaddress("Hyd");
   Thread.sleep(2000);
}

@Then("^the page should be navigated to paymentdetails page$")
public void the_page_should_be_navigated_to_paymentdetails_page() throws Throwable {
   Alert alt=driver.switchTo().alert();
	Thread.sleep(2000);
	String msg=alt.getText();
	System.out.println(msg);
	alt.accept();
	Thread.sleep(2000);
driver.navigate().to("file:///C:/Users/DMUKKAMA/Desktop/applications/module3exam/PaymentDetails.html");
	System.out.println("Navigated Successfully");
Thread.sleep(2000);
	driver.close();
	}

}
