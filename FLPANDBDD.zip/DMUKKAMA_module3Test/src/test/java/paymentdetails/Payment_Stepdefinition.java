package paymentdetails;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageFact.PageClass;

public class Payment_Stepdefinition {
	
	WebDriver driver;
	PageClass pg;

	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "c:\\Selenium Lib\\chromedriver.exe");
		driver = new ChromeDriver();
		pg = new PageClass(driver);
	
	}
	
	
	
	@Given("^customer is on Make Payment page$")
	public void customer_is_on_Make_Payment_page() throws Throwable {
	    driver.get("file:///C:/Users/DMUKKAMA/Desktop/applications/module3exam/PaymentDetails.html");
	}
	
	@When("^customer checks the title of the page$")
	public void customer_checks_the_title_of_the_page() throws Throwable {
		String expected_title=driver.getTitle();
		   System.out.println(expected_title);
	}

	@Then("^the title is \"([^\"]*)\"$")
	public void the_title_is(String arg1) throws Throwable {
		   String expected_title=driver.getTitle();
			 if(expected_title.contentEquals(arg1)) {
				 System.out.println("title is same");
			 }else {
				 System.out.println("title mismatch");
			 }
			   driver.close();
	}

	@When("^customer didnot gave cardholders name$")
	public void customer_didnot_gave_cardholders_name() throws Throwable {
	   pg.setCardHolder("");Thread.sleep(2000);
	}

	@When("^clicks on makepayment button$")
	public void clicks_on_makepayment_button() throws Throwable {
	 pg.clickMbutton();
	}

	@Then("^a popup should come saying cardholders name is empty$")
	public void a_popup_should_come_saying_cardholders_name_is_empty() throws Throwable {
		Alert alt=driver.switchTo().alert();
		Thread.sleep(2000);
		String msg=alt.getText();
		System.out.println(msg);
		alt.accept();
		driver.close();
	}

	@When("^customer didnot gave debit card number$")
	public void customer_didnot_gave_debit_card_number() throws Throwable {
		 pg.setCardHolder("Harsha");
	}

	@Then("^a popup should be diplayed saying \"([^\"]*)\"$")
	public void a_popup_should_be_diplayed_saying(String arg1) throws Throwable {
		Alert alt=driver.switchTo().alert();
		Thread.sleep(2000);
		String msg=alt.getText();
		System.out.println(msg);
		alt.accept();
		System.out.println(arg1);
		driver.close();
	}

	@When("^customer didnot gave card expiry month field$")
	public void customer_didnot_gave_card_expiry_month_field() throws Throwable {
		pg.setCardHolder("Harsha");
		   pg.setDebit("123412341234");
		   pg.setCvv("245");
		   Thread.sleep(2000);
	}

	@When("^customer didnot gave card expiry year field$")
	public void customer_didnot_gave_card_expiry_year_field() throws Throwable {
		 pg.setCardHolder("Harsha");
		   pg.setDebit("123412341234");
		   pg.setCvv("245");
		   pg.setMonth("03");
		   Thread.sleep(2000);
	}

	@When("^customer gave all details$")
	public void customer_gave_all_details() throws Throwable {
	   pg.setCardHolder("Harsha");
	   pg.setDebit("123412341234");
	   pg.setCvv("245");
	   pg.setMonth("03");
	   pg.setYear("2019");
	}


}
