package paymentdetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
/**
 * 
 * @author SRBORUSU
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" })
public class Payment_Testrunner {

}
