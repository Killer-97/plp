package com.capstore.boot.service;

import java.text.ParseException;

public interface IDiscountService {

	

	boolean adddiscount(int product_id, String promoname, String promoamt, String disper, String idate, String edate) throws ParseException;

}
