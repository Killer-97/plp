package com.capstore.boot.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.CustomerDao;
import com.capstore.boot.model.Customer;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.findAll();
	}
    


	@Override
	public List<Customer> getAllCustomerEmail() {
	
		return customerDao.findAll();
	}
	@Override
    public Customer findOne(Integer customerId){
    	return customerDao.getOne(customerId);
    }
	@Override
    public List<Customer> getAllCustomer(){
    	return (List<Customer>) customerDao.findAll();
    }



	@Override
	public Customer findByEmailId(String emailId) {
		// TODO Auto-generated method stub
		return customerDao.findByemailId(emailId);
	}



	@Override
	public boolean createcustomer(Customer customer) {
		
		Customer c = customerDao.findByemailId(customer.getEmailId());
	boolean status = false;
		
		if(c==null) {
			customerDao.save(customer);
			status=true;
			return status;
		}
	return status;
		
	}

}
