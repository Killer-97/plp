package com.capstore.boot.model;

public class Store {

}
