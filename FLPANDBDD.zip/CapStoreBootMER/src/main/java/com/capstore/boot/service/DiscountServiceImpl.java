package com.capstore.boot.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.DiscountDao;
import com.capstore.boot.model.Discount;

@Service
public class DiscountServiceImpl implements IDiscountService {

	@Autowired
	DiscountDao dao;

	@Override
	public boolean adddiscount(int product_id, String promoname, String promoamt, String disper, String idate,
			String edate) throws ParseException {
		if(dao.findByproductid(product_id)==null) {
		int amount=Integer.parseInt(promoamt);
		int percent=Integer.parseInt(disper);
		 Date issuedate=new SimpleDateFormat("dd/MM/yyyy").parse(idate);  
		 Date expirydate=new SimpleDateFormat("dd/MM/yyyy").parse(edate);  
	dao.save(new Discount(product_id, amount, percent, issuedate, expirydate, promoname));
		return true;
		}
		else return false;
	}

	
	
	
}
