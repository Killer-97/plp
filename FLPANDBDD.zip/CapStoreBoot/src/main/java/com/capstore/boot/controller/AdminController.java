package com.capstore.boot.controller;

import java.util.List;
                          

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.CustomerService;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchantService;

import oracle.net.aso.p;


@Controller
public class AdminController {


	@Autowired
	CustomerService customerService;
	@Autowired
	MerchantService merchantService;
	
	@Autowired
	InventoryService inventoryService;
	

	@RequestMapping("/adminpage")
	public String adminpage() {
		return "adminpage";
	}
	
	@RequestMapping("/homepage")
	public String starthome()
	{
		return "home";
		
	}
	
	
	
	/*@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("merchant") Merchant merchant)
	{
		
		merchantService.updateMerchant(merchant);
		return "redirect:Merchants/";
		
	}
	*/
	@RequestMapping(value="/addMerchant", method = RequestMethod.GET)
	public String addEmployee(@ModelAttribute("merch") Merchant merchant ){
		return "Add_Merchant";
	}
	
	
	
	
	
	@RequestMapping("/Customers")
	public String showCustomerList(Model m){
		List<Customer> clist=customerService.getAllCustomer();
		m.addAttribute("cList", clist);
		return "Customers";
	}
	
	@RequestMapping("/Merchants")
	public String showMerchantList(Model m){
		List<Merchant> mlist=merchantService.getAllMerchant();
		m.addAttribute("mList", mlist);
		return "Merchants";
	}
	
	@RequestMapping("/Products")
	public String showProductList(Model m){
		
		List<Inventory> plist = inventoryService.getAllInventory();
		m.addAttribute("plist", plist);
		return "Products";
	}
	
	
	
	

	@RequestMapping("/discount")
	public String showdiscount(Model m) {
		return "discount";
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam int merchantId)
	{
		
		merchantService.deleteMerchant(merchantId);
		return "";
	}
	
	@RequestMapping("/deletecustomer")
	public String deletecustomer(@RequestParam int customerId)
	{
		
		customerService.deletecustomer(customerId);
		return "CustomerpageForAdmin";
	}
	
	
	/*
	@RequestMapping("/getUpdatePage")
	public String updateMerchant(@RequestParam int merchantId,Model m) {
		
	   Merchant mer =merchantService.findMerchantById(merchantId);
		m.addAttribute("command",mer);
		
		
		return "getUpdatePage";
	}*/
	/*@RequestMapping("/updateform")
	public String updateform(@RequestParam int pid,Model m)
	{
		Product product = productDao.getbyId(pid);
		m.addAttribute("command",product);
		return "updateform";
		
	}
	
	@RequestMapping("delete")
	public String delete(@RequestParam int pid)
	{
		productDao.delete(pid);
		return "redirect:/viewproduct";
	}
	

	@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("product") Product product)
	{
		
		productDao.update(product);
		return "redirect:/viewproduct";
		
	}*/
	
	/*@RequestMapping("/coupon")
	public String showCoupon(Model m)
	{
		
		return "coupon";
	}*/
	
	
	/*@RequestMapping("/getUpdatePage1")
	public ModelAndView updateCustomer(HttpServletRequest request) {
		
		ModelAndView view=new ModelAndView();
		
		String emailId = request.getParameter("email");
		Customer c=customerService.findByEmailId(emailId);
		
		view.addObject("customer",c);
		return view;
	}*/
}
