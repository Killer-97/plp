package com.capstore.boot.service;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.CustomerDao;
import com.capstore.boot.dao.IPasswordDao;
import com.capstore.boot.dao.MerchantDao;
import com.capstore.boot.model.Customer;


@Service("passwordService")
public class PasswordServiceImpl implements IPasswordService {

	@Autowired
	CustomerDao customerDao;
	
	@Autowired
	MerchantDao merchantDao;
	
	
/*	@Override
	public Customer forgotPassword(String email,String password) {
		
		Customer customer=customerDao.findByemailId(email);
		
		if(customer!=null) {
			String pass=encrypt(password);
			customer.setPassword(pass);
			customerDao.save(customer);
		}
		return null;
	}
	
	@Override
	public Customer  findBycustomeremail(String email) {
		Customer customer=customerDao.findByemail(email);
		System.out.println("customer is find");
		return customer;
	}

	@Override
	public Merchant findBymerchantemail(String email) {
		Merchant merchant=merchantDao.findByemail(email);
		System.out.println("email found");
		return merchant;
	}
	@Override
	public Merchant changePasswords(String email, String password) {
		Merchant merchant = merchantDao.findByemail(email);
		if(merchant!=null) {
			String pass=encrypt(password);
			merchant.setPassword(pass);
			merchantDao.save(merchant);
		}
		return null;
	}*/
	public String encrypt(String str) {
		// Getting encoder
		Base64.Encoder encoder = Base64.getEncoder();

		//encrypted String
		String ecode = encoder.encodeToString(str.getBytes());
		return ecode;
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer changePassword(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
