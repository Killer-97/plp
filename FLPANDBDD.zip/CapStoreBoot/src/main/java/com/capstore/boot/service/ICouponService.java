package com.capstore.boot.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.model.coupon;





public interface ICouponService {
 
	List<coupon> getAllCoupons();
	
	

	coupon validateCoupon(String name);

	coupon addCoupon(String cname, double amount, String desc, Date idate, Date edate);



	void deleteCoupon(int couponid);
}
