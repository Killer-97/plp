package com.capstore.boot.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.CustomerService;
import com.capstore.boot.service.MerchantService;

@Controller
public class LoginController {
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	MerchantService merchantService;

	@RequestMapping("/logininto")
	public ModelAndView login(HttpServletRequest request, Model m) {
		
		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		String opt = request.getParameter("rd");
		System.out.println(opt);
		String emailId = request.getParameter("email");
		String password = request.getParameter("password");
		view.setViewName("home");
		if (opt.charAt(0) == 'a') {
			if (emailId.equals(password)) {
				view.setViewName("adminpage");
			} else {
				m.addAttribute("msg", "admin not found");
				view.setViewName("login");
			}

		} else if (opt.charAt(0) == 'm') {
			try {
				Merchant mer = merchantService.findByMerchantEmail(emailId);
				
				if (emailId.equals(mer.getEmailId()) && password.equals(mer.getPassword())) {
					session.setAttribute("user", mer);
					view.setViewName("merchantpage2");
				} else {
					m.addAttribute("msg", "merchant not found");
					view.setViewName("login");
				}
			} catch (NullPointerException ne) {
				m.addAttribute("msg", "merchant not found");
				view.setViewName("login");
			}

		} else {
			try {
				Customer cus = customerService.findByEmailId(emailId);
				if ((emailId.equals(cus.getEmailId())) && password.equals(cus.getPassword())) {
					session.setAttribute("user", cus);
					view.setViewName("home1");
				} else {
					m.addAttribute("msg", "customer not found");
					view.setViewName("login");
				}
			} catch (NullPointerException ne) {
				m.addAttribute("msg", "customer not found");
				view.setViewName("login");
			}

		}

		return view;
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		
		return "home";
	}

	@RequestMapping("/forgotpassword")
	public String openforgotpassword() {
		return "forgotpassword";
	}
	
	
	@RequestMapping("/changeforgotpassword")
   public ModelAndView forgot(HttpServletRequest request, Model m) {
		
		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		
		
		String opt = request.getParameter("rd");
		System.out.println(opt);
		String emailId = request.getParameter("emailid");
		
		
		
		 if (opt.charAt(0) == 'm') {
			try {
				
				Merchant mer = merchantService.findByMerchantEmail(emailId);
		
				if (emailId.equals(mer.getEmailId())) {
					
			    view.setViewName("changeforgotpassword");
				}
			} catch (NullPointerException ne) {
				m.addAttribute("status", "merchant email not found!!");
				view.setViewName("forgotpassword");
			}

		} else {
			try {
				Customer cus = customerService.findByEmailId(emailId);
				if ((emailId.equals(cus.getEmailId())) ) /*&& password.equals(cus.getPassword()))*/{
					session.setAttribute("user", cus);
					view.setViewName("home1");
				} else {
					m.addAttribute("msg", "customer not found");
					view.setViewName("login");
				}
			} catch (NullPointerException ne) {
				m.addAttribute("msg", "customer not found");
				view.setViewName("login");
			}

		}

		return view;
	}
	
	
	
	
}
