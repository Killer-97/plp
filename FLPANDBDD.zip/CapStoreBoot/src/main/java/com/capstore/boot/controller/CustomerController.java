package com.capstore.boot.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.ServletContextLiveBeansView;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.service.CustomerService;

@Controller
public class CustomerController {

	
	@Autowired
	CustomerService customerService;
	
	
	@RequestMapping("/registerascustomer")
	public String register() {
		return "customerRegisterform";
	}
	
	
	@RequestMapping("/savecustomer")
	public ModelAndView addProduct(HttpServletRequest request) {
		
		ModelAndView modelView = new ModelAndView();
		
		Customer customer = new Customer();
		
		String firstname = request.getParameter("fn");
		String lastname = request.getParameter("ln");
		customer.setCustomerName(firstname+lastname);
		

		String phoneno = request.getParameter("phoneno");
		customer.setPhoneNumber(phoneno);
		
		String emailId = request.getParameter("email");
		customer.setEmailId(emailId);
		
		String password = request.getParameter("password");
		customer.setPassword(password);
	
		boolean status = customerService.createcustomer(customer);
		if(status==true) {
			
			modelView.setViewName("home");
		}else {
			modelView.addObject("msg", "Customer with this Email already exists!!");
			modelView.setViewName("customerRegisterform");
		}
		
		return modelView;
	}
}
