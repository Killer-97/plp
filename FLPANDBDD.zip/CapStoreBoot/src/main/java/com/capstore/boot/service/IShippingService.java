package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Address;
import com.capstore.boot.model.Customer;
//import com.capstore.boot.model.Email;
import com.capstore.boot.model.Order;
import com.capstore.boot.model.Shipping;


public interface IShippingService {
	public List<Address> findAll(Integer custId);

	public void addAddress(Address address);

	public void addShipping(Shipping shipping);

	public List<Shipping> getShipping();
/*
	public void addEmail(Email email);

	public List<Email> getEmail();*/

	public Customer findCustomer(Integer custId);

	public Order findOrder(Integer orderId);
	
}
