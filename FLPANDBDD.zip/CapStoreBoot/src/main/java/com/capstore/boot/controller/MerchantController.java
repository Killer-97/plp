package com.capstore.boot.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Address;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchantService;


@Controller
public class MerchantController {

	
	@Autowired
	 MerchantService merchantService;
@Autowired	
InventoryService inventory;	

	
	@RequestMapping("/registerasmerchant")
	public String register() {
		return "merchantRegisterform";
	}
	
	
	@RequestMapping("/saveasmerchant")
	public ModelAndView addProduct(HttpServletRequest request) {
		
		ModelAndView modelView = new ModelAndView();
		
		Merchant merchant = new Merchant();
		Address address = new Address();
		
		String MerchantName = request.getParameter("mn");
		merchant.setMerchantname(MerchantName);
		
		String email = request.getParameter("memail");
		merchant.setEmailId(email);
		
		String password = request.getParameter("mpass");
		merchant.setPassword(password);
		
		String companyname = request.getParameter("cn");
		merchant.setCompanyName(companyname);
		
		String companyaddress = request.getParameter("ca");
		address.setZipcode(500072);
		address.setStreetNumber(12);
		List<Address> list1 =Arrays.asList(address);
		merchant.setAddress(list1);
		
		String phoneno = request.getParameter("pn");
		merchant.setPhoneNo(phoneno);
		
		String merchanttype=request.getParameter("mt");
		merchant.setIsCertified(merchanttype);

		
		boolean status = merchantService.saveMerchant(merchant);
		
		if(status==true) {
			
			modelView.setViewName("home");
		}else {
			modelView.addObject("msg", "Merchant with this Email already exists!!");
			modelView.setViewName("merchantRegisterform");
		}
     	 
		return modelView;
	}
	
	@RequestMapping(value="/addProduct", method = RequestMethod.GET)
	public String addEmployee(@ModelAttribute("merch") Merchant merchant ){
		return "AddProduct";
	}

	@RequestMapping(value="/savemerch",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@ModelAttribute("merch") Merchant merchant,BindingResult result){

		if(result.hasErrors()){

			return new ModelAndView("Add_Merchant");
		}
		else
		{
			merchantService.saveMerchant(merchant);

			return new ModelAndView("home");
		}
	}
	
	@RequestMapping("/merchantpage")
	public String merchantpage(){
		return "merchantpage";
	}
	
	/*@RequestMapping(value="/deleteMerchant",method = RequestMethod.GET)
	public String deleteMerchant(){

		return "Delete_Merchant";
	}*/

	@RequestMapping(value="/deletemerch",method = RequestMethod.GET)
	public String merchantDelete(@RequestParam("merchantId") Integer merchantUId){
		merchantService.deleteMerchant(merchantUId);
		return "home";

	}
	
	/*@RequestMapping("/delete")
	public String delete(@RequestParam int productId)
	{
		productDao.delete(productId);
		return "redirect:/viewproduct";
	}*/
	@RequestMapping(value="/showAllMerchant",method = RequestMethod.GET)
	public ModelAndView showAllTrainee(){
		List<Merchant> allmerchant=merchantService.getAllMerchant();
		return new ModelAndView("showAll","merchantList", allmerchant);
	}
	
	/*
	@RequestMapping(value="/showAllThirdPartyMerchant",method = RequestMethod.GET)
	public ModelAndView getAllThirdmer()
	{
		
		List<Merchant> allThirdMerchants =  merchantService.getAllMerchant1();
		return new ModelAndView("showAllThirdParty","thirdPartyMerList",allThirdMerchants);
		
	}*/
	
	/*@RequestMapping(value="/productsOfThirdPartyMerchant",method=RequestMethod.GET)
	public ModelAndView allprodDetailsOfThirdMer(Model model)
	{
		List<Inventory> prodDetails=null;
		List<Inventory> allProdDetails= new ArrayList<Inventory>();		
		List<Merchant> merchantId=merchantService.getAllMerchant();
		System.out.println(merchantId);
		Iterator it = merchantId.iterator();
		while(it.hasNext())
		{
			String merId = (String) it.next();
			prodDetails = merchantService.allProductsOfThirdParty(merId);
			allProdDetails.addAll(prodDetails);
			System.out.println( allProdDetails);
			
			
		}
		return new ModelAndView("allProdsOfThirdParty","list", allProdDetails);
		
		
	
	
}*/
	@RequestMapping(value="/showallproduct",method = RequestMethod.GET)
	public ModelAndView showallproduct(){
		List<Inventory> allproduct=inventory.getAllInventory();
		return new ModelAndView("showAll","merchantList", allproduct);
	}
	
}
