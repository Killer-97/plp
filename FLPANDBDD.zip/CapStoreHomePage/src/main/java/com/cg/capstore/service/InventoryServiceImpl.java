package com.cg.capstore.service;



import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.BrandDao;
import com.cg.capstore.dao.ICategoryDao;
import com.cg.capstore.dao.InventoryDao;
import com.cg.capstore.dto.Brand;
import com.cg.capstore.dto.Category;
import com.cg.capstore.dto.Store;

@Service("inventoryService")
@Transactional
public class InventoryServiceImpl implements InventoryService {
	@Autowired
    InventoryDao inventoryDao;
	
	@Autowired
	private BrandDao brandDao;
	
	@Autowired
	private ICategoryDao categoryDao;
	
	@Override
    public List<Store> getAllInventories(){
    	return (List<Store>) inventoryDao.findAll();
    }

	@Override
	public void save1(Store product) {
		inventoryDao.save(product);
	}
	
	@Override
	public void delete(Integer productId) {
		// TODO Auto-generated method stub
		inventoryDao.deleteById(productId);
	}

	@Override
	public List<Store> getAll() {
		// TODO Auto-generated method stub
		return inventoryDao.findAll();
	}

		@Override
	public List<Brand> getAllBrands() {
		// TODO Auto-generated method stub
		return brandDao.findAll();
	}

	@Override
	public List<Category> getAllCategories() {
		
		return categoryDao.findAll();
	}

	@Override
	public void save(Brand br) {
		brandDao.save(br);
		
	}

	@Override
	public void save2(Category cg) {
		categoryDao.save(cg);
		
	}


	

	/*@Override
	public Store findProduct(Integer productId) {
		// TODO Auto-generated method stub
	 StoreDao.findProduct(productId);
	}
	*/
	
	
	
}
