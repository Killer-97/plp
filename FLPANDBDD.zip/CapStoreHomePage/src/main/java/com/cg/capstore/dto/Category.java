package com.cg.capstore.dto;



import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Component
public class Category {
	@Id
	@GeneratedValue(generator="cust1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust1",sequenceName="Category1",initialValue=1,allocationSize=1)
private int categoryId;
private String categoryName;
@OneToOne(fetch=FetchType.LAZY)
@JoinColumn(name="discountId")
private Discount dis;
@OneToMany(targetEntity=Store.class, fetch=FetchType.LAZY)
private List<Store> Store;
public int getCategoryId() {
	return categoryId;
}
public void setCategoryId(int categoryId) {
	this.categoryId = categoryId;
}
public String getCategoryName() {
	return categoryName;
}
public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
}
public Discount getDis() {
	return dis;
}
public void setDis(Discount dis) {
	this.dis = dis;
}
public List<Store> getStore() {
	return Store;
}
public void setStore(List<Store> Store) {
	this.Store = Store;
}
public Category(int categoryId, String categoryName, Discount dis, List<Store> Store) {
	super();
	this.categoryId = categoryId;
	this.categoryName = categoryName;
	this.dis = dis;
	this.Store = Store;
}
public Category() {
	super();
}

}
