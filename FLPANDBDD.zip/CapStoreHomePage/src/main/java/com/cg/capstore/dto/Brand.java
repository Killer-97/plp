package com.cg.capstore.dto;




import java.util.List;


import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;




@Entity
@Component
public class Brand {
@Id
@GeneratedValue(generator="cust1",strategy=GenerationType.SEQUENCE)
@SequenceGenerator(name="cust1",sequenceName="Brand1",initialValue=1,allocationSize=1)
private int brandId;
private String brandName;
/*@OneToMany(targetEntity=Store.class, mappedBy="Brand")*/
private List<Store> Store;

public Brand() {
super();
}


public int getBrandId() {
return brandId;
}

public void setBrandId(int brandId) {
this.brandId = brandId;
}

public String getBrandName() {
return brandName;
}

public void setBrandName(String brandName) {
this.brandName = brandName;
}



public List<Store> getStore() {
return Store;
}



public void setStore(List<Store> Store) {
this.Store = Store;
}



public Brand(int brandId, String brandName, List<Store> Store) {
super();
this.brandId = brandId;
this.brandName = brandName;
this.Store = Store;
}








}