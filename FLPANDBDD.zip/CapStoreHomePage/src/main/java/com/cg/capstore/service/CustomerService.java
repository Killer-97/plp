package com.cg.capstore.service;

import java.util.List;



import com.cg.capstore.dto.Customer;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Store;

public interface CustomerService {
	public Customer createAccount(String firstName,String lastName,String phoneNo,String emailId,String password);
	Customer findByEmailId(String emailId);
	List<Customer> getAllCustomers();
	List<Merchant> getAllMerchants();
	List<Store> getAllProducts();
}
