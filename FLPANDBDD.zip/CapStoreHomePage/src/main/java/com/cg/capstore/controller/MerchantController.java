package com.cg.capstore.controller;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Store;
import com.cg.capstore.service.CustomerService;
import com.cg.capstore.service.MerchantService;

@Controller("merchantController")
public class MerchantController {
	@Autowired
	 MerchantService merchantService;
	
	@RequestMapping("/merchantRegister")
	public String register() {
		return "merchantRegister";
	}
	
	
	@RequestMapping("/save")
	public String addProduct(HttpServletRequest request) {
		String MerchantName = request.getParameter("mn");
		String email = request.getParameter("memail");
		String password = request.getParameter("mpass");
		String companyname = request.getParameter("cn");
		String companyaddress = request.getParameter("ca");
		String phoneno = request.getParameter("pn");
		String merchanttype=request.getParameter("mt");
        merchantService.createMerchantAccount(MerchantName, email, password, companyname, companyaddress, phoneno, merchanttype,0,"");
		return "home";
	}
	
	@RequestMapping(value="/addMerchant", method = RequestMethod.GET)
	public String addEmployee(@ModelAttribute("merch") Merchant merchant ){
		return "Add_Merchant";
	}

	@RequestMapping(value="/savemerch",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@ModelAttribute("merch") Merchant merchant,BindingResult result){

		if(result.hasErrors()){

			return new ModelAndView("Add_Merchant");
		}
		else
		{
			merchantService.save(merchant);

			return new ModelAndView("home");
		}
	}
		/*@RequestMapping("/savemerchant")
		public String addProduct(HttpServletRequest request) {
			String firstname = request.getParameter("fn");
			String lastname = request.getParameter("ln");
			String phoneno = request.getParameter("phoneno");
			String emailId = request.getParameter("email");
			String password = request.getParameter("password");
	}*/
	@RequestMapping(value="/deleteMerchant",method = RequestMethod.GET)
	public String deleteMerchant(){

		return "Delete_Merchant";
	}

	@RequestMapping(value="/deletemerch",method = RequestMethod.GET)
	public String merchantDelete(@RequestParam("merchantId") String merchUId){
		merchantService.delete(merchUId);
		return "home";

	}
	
	/*@RequestMapping("/delete")
	public String delete(@RequestParam int productId)
	{
		productDao.delete(productId);
		return "redirect:/viewproduct";
	}*/
	@RequestMapping(value="/showAllMerchant",method = RequestMethod.GET)
	public ModelAndView showAllTrainee(){
		List<Merchant> allmerchant=merchantService.loadAll();
		return new ModelAndView("showAll","merchantList", allmerchant);
	}
	
	
	@RequestMapping(value="/showAllThirdPartyMerchant",method = RequestMethod.GET)
	public ModelAndView getAllThirdmer()
	{
		
		List<Merchant> allThirdMerchants =  merchantService.getAllThirdPartyMerchants();
		return new ModelAndView("showAllThirdParty","thirdPartyMerList",allThirdMerchants);
		
	}
	
	@RequestMapping(value="/productsOfThirdPartyMerchant",method=RequestMethod.GET)
	public ModelAndView allprodDetailsOfThirdMer(Model model)
	{
		List<Store> prodDetails=null;
		List<Store> allProdDetails= new ArrayList<Store>();		
		List<Merchant> merchantId=merchantService.getThirdPartyMerId();
		System.out.println(merchantId);
		Iterator it = merchantId.iterator();
		while(it.hasNext())
		{
			String merId = (String) it.next();
			prodDetails = merchantService.allProductsOfThirdParty(merId);
			allProdDetails.addAll(prodDetails);
			System.out.println( allProdDetails);
			
			
		}
		return new ModelAndView("allProdsOfThirdParty","list", allProdDetails);
		
		
	}
	
	
}
