package com.cg.capstore.dto;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Component
public class InvoiceProduct {
	@Id
	@GeneratedValue(generator="cust1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust1",sequenceName="InvoiceProduct1",initialValue=1,allocationSize=1)
private int invoiceProductId;
	@OneToMany(fetch=FetchType.LAZY)
private List<Store> Store;
/*	@OneToOne(targetEntity = GenerateInvoice.class, mappedBy = "invoiceProduct")
*/	private GenerateInvoice generateInvoice;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="discountId")
	private Discount discount;
	public InvoiceProduct() {
		super();
	}

	public int getInvoiceProductId() {;
		return invoiceProductId;
	}

	public void setInvoiceProductId(int invoiceProductId) {
		this.invoiceProductId = invoiceProductId;
	}

	public InvoiceProduct(int invoiceProductId, GenerateInvoice generateInvoice) {
		super();
		this.invoiceProductId = invoiceProductId;
		this.generateInvoice = generateInvoice;
	}

	public GenerateInvoice getGenerateInvoice() {
		return generateInvoice;
	}

	public void setGenerateInvoice(GenerateInvoice generateInvoice) {
		this.generateInvoice = generateInvoice;
	}

	public List<Store> getStore() {
		return Store;
	}

	public void setStore(List<Store> Store) {
		this.Store = Store;
	}

	public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	public InvoiceProduct(int invoiceProductId, List<Store> Store, GenerateInvoice generateInvoice,
			Discount discount) {
		super();
		this.invoiceProductId = invoiceProductId;
		this.Store = Store;
		this.generateInvoice = generateInvoice;
		this.discount = discount;
	}

	}
