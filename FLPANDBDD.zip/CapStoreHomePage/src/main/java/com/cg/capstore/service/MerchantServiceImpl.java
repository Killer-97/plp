package com.cg.capstore.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.MerchantRepository;
import com.cg.capstore.dto.Merchant;

import com.cg.capstore.dto.Store;
@Service("merchantService")
public class MerchantServiceImpl implements MerchantService{
	@Autowired
	MerchantRepository merchantRepository;
	@Override
	public Merchant createMerchantAccount(String merchantname, String MerchantEmail,String password ,String Companyname,
			String CompanyAddress, String phone_no,String merchantType,int flag, String rating) {
		
		Merchant m=new Merchant(merchantname, MerchantEmail, password, Companyname,CompanyAddress, phone_no, merchantType,0,"");
		merchantRepository.save(m);
		return m;
	}
	
	public Merchant findByMerchantEmail(String MerchantEmail) {
		return merchantRepository.findByMerchantEmail(MerchantEmail);
	}
	
	public void save(Merchant merchant) {
		// TODO Auto-generated method stub
		merchantRepository.save(merchant);
	}

	@Override
	public void delete(String merchantId) {
		
		merchantRepository.deleteById(merchantId);
	}

	@Override
	public List<Merchant> loadAll() {
		
		return merchantRepository.findAll();
	}

	@Override
	public List<Merchant> getAllThirdPartyMerchants() {
		// TODO Auto-generated method stub
		/*return merchantRepository.getAllThirdPartyMerchants();*/
	return null;
	}

	@Override
	public List<Merchant> getThirdPartyMerId() {
		// TODO Auto-generated method stub
	/*	return merchantRepository.getThirdPartyMerId();*/
		return null;
	}

	@Override
	public List<Store> allProductsOfThirdParty(String merId) {
		// TODO Auto-generated method stub
		/*return merchantRepository.allProductsOfThirdParty(merId);*/
		return null;
	}


}
