package com.cg.capstore.dao;



import javax.transaction.Transactional;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Store;



@Repository("inventoryDao")

@Transactional
public interface InventoryDao extends JpaRepository<Store, Integer>{
	
	@Query("select i from Store i where i.productName=:product")
	Store findOne(@Param("product") String product);
	
}
