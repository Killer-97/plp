package com.cg.capstore.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Brand;


@Repository("brandDao")
public interface BrandDao extends JpaRepository<Brand, Integer> {

}
