package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Brand;
import com.cg.capstore.dto.Category;
import com.cg.capstore.dto.Store;




public interface InventoryService {

	public void save1(Store product);
	public void save(Brand br);
	public void save2(Category cg);
    public void delete(Integer productId) ;
    
    
    
    public List<Store> getAll();
	List<Store> getAllInventories();
	public List<Brand> getAllBrands();
	public List<Category> getAllCategories();
}
