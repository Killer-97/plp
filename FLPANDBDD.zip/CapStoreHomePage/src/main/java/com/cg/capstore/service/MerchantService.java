package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Store;

public interface MerchantService {
	public Merchant createMerchantAccount(String merchantname,String MerchantEmail,String password,String Companyname,String CompanyAddress,String phone_no,String merchantType,int flag, String rating);
	Merchant findByMerchantEmail(String MerchantEmail);
	public void save(Merchant merchant);
	public void delete(String merchantId);
	public List<Merchant> loadAll();
	public List<Merchant> getAllThirdPartyMerchants();
	public List<Merchant> getThirdPartyMerId();
	public List<Store> allProductsOfThirdParty(String merId);
}
