package com.cg.capstore.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Category;



@Repository("categoryDao")
public interface ICategoryDao extends JpaRepository<Category, Integer> {

}
