package com.capstore.boot.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.coupon;
import com.capstore.boot.service.ICouponService;

@Controller("couponController")
public class CouponController {

	@Autowired
	ICouponService service;
	
	/*@RequestMapping("/coupon")
	public String adminpage1() {
		return "coupon";
	}*/
	@RequestMapping("/addcoupon")
	public String couponregister() {
		return "addcoupon";
	}
	
	@RequestMapping("/addcoupons")
	public  String  addcoupons(HttpServletRequest request) throws ParseException {
		
		String cname = request.getParameter("cname");
		String desc = request.getParameter("desc");
		Date idate=new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("idate"));
		Date edate=new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("edate"));
		double amount =Double.parseDouble(request.getParameter("amount"));
		coupon c=service.addCoupon(cname,amount,desc,idate,edate);
		if(c!=null)
			return "coupon";
		else
			return "addcoupons";
	}
	
@RequestMapping("/viewall")
public String listCoupon(Model m) throws IOException {

List<coupon> listCoupon = service.getAllCoupons();
System.out.println(listCoupon);
m.addAttribute("listCoupon", listCoupon);
		
		return "viewall";
	}


@RequestMapping("/apply")
public String applyCoupon(HttpServletRequest request) {
	HttpSession session=request.getSession();
	//double totalprice=(double) session.getAttribute("total");
	double totalprice=100000;
	String code=request.getParameter("cname");
	coupon c=service.validateCoupon(code);
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date cdate = new Date();
	System.out.println(cdate);
	if(c!=null ) {
	Date idate=c.getIssueDate();
	Date  edate=c.getExpiryDate();
		if(idate.compareTo(cdate) * cdate.compareTo(edate) >= 0) {
			double finalprice=totalprice-c.getCouponAmount();
			if( finalprice>0)
			{
				session.setAttribute("fin", finalprice);
			}
		}
	}
	return "final";
	
}
@RequestMapping("/order")
public String orderpage() {
	return "order";
}
@RequestMapping("/final")
public String finalp() {
	return "final";
}
@RequestMapping("/pay")
public String payamount(HttpServletRequest request) {
	return "TransactionPage";
	
}

/*@RequestMapping("/deletecoupon")
public  String  deletecoupons(HttpServletRequest request)
{
	String couponid=request.getParameter("couponid");
	service.deleteCoupon(couponid);
	return "addcoupon";
	}
*/
@RequestMapping("/deletecoupon")
public  ModelAndView  deletecoupons(HttpServletRequest request,Model m)
{ModelAndView modelAndView = new ModelAndView();
	int couponid=Integer.parseInt(request.getParameter("couponid"));
	
	service.deleteCoupon(couponid);
	
	List<coupon> listCoupon = service.getAllCoupons();
	System.out.println(listCoupon);
	m.addAttribute("listCoupon", listCoupon);
	
	modelAndView.setViewName("viewall");
	return modelAndView;
	}
}
