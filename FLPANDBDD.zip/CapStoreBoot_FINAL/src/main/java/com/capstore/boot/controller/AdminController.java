package com.capstore.boot.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Address;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.CustomerService;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchantService;


@Controller
public class AdminController {


	@Autowired
	CustomerService customerService;
	@Autowired
	MerchantService merchantService;
	@Autowired
	InventoryService inventoryService;
	
	
	@RequestMapping("/adminpage")
	public String adminpage() {
		return "adminpage";
	}
	
	
	@RequestMapping("/homepage")
	public String starthome()
	{
		return "home";
		
	}
	
	/*@RequestMapping("/getUpdatePage")
	public ModelAndView updateCustomer(HttpServletRequest request) {
		
		ModelAndView view=new ModelAndView();
		
		String emailId = request.getParameter("customermail");
		Customer c=customerService.findByEmailId(emailId);
		
		view.addObject("customer",c);
		
		view.setViewName("UpdateCustomerform");
		
		
		
		return view;
	}*/

	
	@RequestMapping("/CustomerPage")
	public String showCustomerList(Model m){
		List<Customer> clist=customerService.getAllCustomers();
		m.addAttribute("cList", clist);
		return "CustomerpageForAdmin";
	}
	
	@RequestMapping("/MerchantPageForAdmin")
	public String showMerchantList(HttpServletRequest request){
		
		HttpSession session=request.getSession();
		
		List<Merchant> mlist=merchantService.getAllMerchant();
		session.setAttribute("merch", mlist);
		
		return "MerchantPageForAdmin";
	}
	
	@RequestMapping("/updateStatus")
	public ModelAndView update(HttpServletRequest request) {
		ModelAndView view=new ModelAndView();
		HttpSession session=request.getSession();
		
		List<Merchant> mlist=(List)session.getAttribute("merch");
		List<Integer> Idlist=new ArrayList<Integer>();
		System.out.println(mlist);
		for(Integer i=0;i<mlist.size();i++) {
			System.out.println(request.getParameter("sts"+i));
			if(request.getParameter("sts"+i)!=null) {
				Idlist.add(Integer.parseInt(request.getParameter("sts"+i)));
			}else {
				Idlist.add(-1);
			}
		}
		System.out.println(Idlist);
		for(int i=0;i<mlist.size();i++) {
			if(Idlist.get(i)!=-1) {
		Merchant m=merchantService.findMerchantById(Idlist.get(i));
		System.out.println(m);
		if(m.getStatus().equals("false")) {
		m.setStatus("true");
		}else {
			m.setStatus("false");
		}
		merchantService.saveMer(m);
			}
		}
		
		
		
		view.setViewName("redirect:/MerchantPageForAdmin");
		
		return view;
	}
	
	
	
	
	@RequestMapping("/Products")
	public ModelAndView showProductList(HttpServletRequest request){
		ModelAndView view=new ModelAndView();
		
      HttpSession session = request.getSession();
		
		
		
		List<Inventory> productlist = inventoryService.getAll();
		
		session.setAttribute("prodlist", productlist);

		view.addObject("list",productlist );
		view.setViewName("ProductPageForAdmin");
		return view;
	}
	
	@RequestMapping("/coupon")
	public String showCoupon(Model m)
	{
		
		return "coupon";
	}
	@RequestMapping("/discount")
	public String showdiscount(Model m) {
		return "discount";
	}
	
	
	@RequestMapping(value="/addMerchant", method = RequestMethod.GET)
	public String addEmployee(){
		return "Add_Merchant";
	}
	
	
	
	
	
	
	@RequestMapping("/Merchants")
	public String showMerchantList(Model m){
		List<Merchant> mlist=merchantService.getAllMerchant();
		m.addAttribute("mList", mlist);
		return "Merchants";
	}
	
/*	@RequestMapping("/Products")
	public String showProductList(Model m){
		
		List<Inventory> plist = inventoryService.getAllInventory();
		m.addAttribute("plist", plist);
		return "Products";
	}
	
	*/
	
	

	@RequestMapping("/delete")
	public String delete(@RequestParam int merchantId)
	{
		
		merchantService.deleteMerchant(merchantId);
		return "MerchantPageForAdmin";
	}
	
	@RequestMapping("/deletecustomer")
	public String deletecustomer(@RequestParam int customerId)
	{
		
		customerService.deletecustomer(customerId);
		return "CustomerpageForAdmin";
	}
	
	

	
	@RequestMapping(value="/savemerch",method=RequestMethod.POST)
	public ModelAndView insertMerch(HttpServletRequest  request){

		ModelAndView modelView = new ModelAndView();

		Merchant merchant = new Merchant();
		Address address = new Address();

		String MerchantName = request.getParameter("mn");
		merchant.setMerchantname(MerchantName);

		String email = request.getParameter("memail");
		merchant.setEmailId(email);

		String password = request.getParameter("mpass");
		merchant.setPassword(password);

		String companyname = request.getParameter("cn");
		merchant.setCompanyName(companyname);

		String companyaddress = request.getParameter("ca");
		address.setZipcode(500072);
		address.setStreetNumber(12);
		List<Address> list1 = Arrays.asList(address);
		merchant.setAddress(list1);

		String phoneno = request.getParameter("pn");
		merchant.setPhoneNo(phoneno);

		String merchanttype = request.getParameter("mt");
		merchant.setIsCertified(merchanttype);

		merchant.setStatus("false");
		
		
		boolean status = merchantService.saveMerchant(merchant);

		if (status == true) {

			modelView.setViewName("home");
		} else {
			modelView.addObject("msg", "Merchant with this Email already exists!!");
			modelView.setViewName("merchantRegisterform");
		}

		return modelView;
		}
	
	
}
