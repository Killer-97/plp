package com.capstore.boot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.CategoryDao;
import com.capstore.boot.model.Inventory;

@Service("categoryService")
public class CategoryServiceImpl  implements CategoryService{

	
	@Autowired
	CategoryDao categoryDao;
	
	
	@Override
	public List<Inventory> findAllBycategoryName(String name) {
		// TODO Auto-generated method stub
		return categoryDao.findAllBycategoryName(name);
	}

}
