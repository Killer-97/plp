package com.capstore.boot.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Discount;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.ManagingCart;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.CategoryService;
import com.capstore.boot.service.InventoryService;

@Controller
public class InventoryController {

	@Autowired
	InventoryService inventoryService;
	
	@Autowired
	CategoryService categoryService;
	
	@RequestMapping("/addProduct")
	public String openaddproduct() {
		return "addProductByMerchant";
	}
	
	@RequestMapping("/saveproduct")
	public ModelAndView addProduct(HttpServletRequest request) throws ParseException {
		
		
		ModelAndView view = new ModelAndView();
		HttpSession session=request.getSession();
		
		Inventory inventory = new Inventory();
		
		
		String productName = request.getParameter("productName");
		inventory.setProductName(productName);
		
		String description = request.getParameter("description");
		inventory.setDescription(description);
		
		Brand brand = new Brand();
		String brandname = request.getParameter("brand");	
		brand.setBrandName(brandname);
		inventory.setBrand(brand);
		
	/*	int views = Integer.parseInt(request.getParameter("views"));
		inventory.setNoOfViews(views);*/
		
		Merchant merchant =((Merchant) session.getAttribute("user"));
		inventory.setMerchant(merchant);
		
		
		Category category = new Category();
		String categoryName = request.getParameter("category");
		category.setCategoryName(categoryName);
		inventory.setCategory(category);
	
		double price = Double.parseDouble(request.getParameter("price"));
		inventory.setPrice(price);
		
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		inventory.setQuantity(quantity);
		
		String exdate = request.getParameter("exdate");
		
		Date expiryDate = new SimpleDateFormat("dd/MM/yyyy").parse(exdate);
		inventory.setExpiryDate(expiryDate);
		
		Discount discount = new Discount();
		int discountpercent = Integer.parseInt(request.getParameter("discount"));
		discount.setDiscountPercent(discountpercent);
		inventory.setDiscount(discount);
		
		
		
		inventoryService.save(brand);
		inventoryService.save2(category);
		inventoryService.save3(discount);
		inventoryService.save1(inventory);
		view.setViewName("afterMerchantLogin");
		return view;
	}
	
	@RequestMapping("/deleteproduct")
	public ModelAndView deleteProductsaddedBymerchant(HttpServletRequest request ,@RequestParam("productid") int pid) {
		
		ModelAndView modelView = new ModelAndView();
		
		HttpSession session = request.getSession();
		
		inventoryService.delete(pid);
		
		Merchant merchant = (Merchant) session.getAttribute("user");
		
		List<Inventory> list =inventoryService.getByMerchantid(merchant.getMerchantId());
		
		
		modelView.addObject("pList", list);
		session.setAttribute("productslist",list );
		
		modelView.setViewName("merchantaddedproducts");
		return modelView;
	}
	
	
	@RequestMapping("/viewbycategory")
	public ModelAndView categoryview(HttpServletRequest request ,@RequestParam("catname") String name) {
	
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		
		List<Inventory> catlist= categoryService.findAllBycategoryName(name);
		
		session.setAttribute("prodlist", catlist);
		
		System.out.println(catlist);

		return modelView;
}
}
