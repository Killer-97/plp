package com.capstore.boot.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.CustomerService;
import com.capstore.boot.service.IPasswordService;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchantService;

@Controller
public class LoginController {
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	MerchantService merchantService;

	@Autowired
	IPasswordService passwordService;
	

	@Autowired
	InventoryService inventoryService;
	
	
	@RequestMapping("/logininto")
	public ModelAndView login(HttpServletRequest request, Model m) {
		
		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		 session = request.getSession();
			
			List<Inventory> productlist = inventoryService.getAll();
			
			view.addObject("plist", productlist);
			
			session.setAttribute("prodlist", productlist);
		
		
		
		String opt = request.getParameter("rd");
		System.out.println(opt);
		String emailId = request.getParameter("email");
		String password = request.getParameter("password");
		
		view.setViewName("home");
		
		if (opt.charAt(0) == 'a') {
			if (emailId.equals("admin")&&(password.equals("admin"))) {
				view.setViewName("adminpage");
			} else {
				m.addAttribute("msg", "admin not found");
				view.setViewName("login");
			}

		} else if (opt.charAt(0) == 'm') {
			try {
				Merchant mer = merchantService.findByMerchantEmail(emailId);
				System.out.println(mer.getStatus());
				if(mer.getStatus().equals("true")) {
				if (emailId.equals(mer.getEmailId()) && password.equals(mer.getPassword())) {
					session.setAttribute("user", mer);
					view.setViewName("afterMerchantLogin");
				} else {
					m.addAttribute("msg", "merchant not found");
					view.setViewName("login");
				}
			} else{
				m.addAttribute("msg", "merchant not authorised by admin");
				view.setViewName("login");
			}
			}catch (NullPointerException ne) {
			
				m.addAttribute("msg", "merchant not found");
				view.setViewName("login");
			}

		}  else {
			try {
				Customer cus = customerService.findByEmailId(emailId);
				if ((emailId.equals(cus.getEmailId())) && password.equals(cus.getPassword())) {
					session.setAttribute("user", cus);
					view.setViewName("home1");
				} else {
					m.addAttribute("msg", "customer not found");
					view.setViewName("login");
				}
			} catch (NullPointerException ne) {
				m.addAttribute("msg", "customer not found");
				view.setViewName("login");
			}

		}

		return view;
	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request) {
		ModelAndView view  =new ModelAndView();
		HttpSession session = request.getSession();
		session.invalidate();
		
		 session = request.getSession();
			
			List<Inventory> productlist = inventoryService.getAll();
			
			view.addObject("plist", productlist);
			
			session.setAttribute("prodlist", productlist);
			view.setViewName("home");
	   return view;
	}
	

	
	
	
	
	
	@RequestMapping("/forgotpassword")
	public String openforgotpassword() {
		return "forgotpassword";
	}
	@RequestMapping("/changeforgotpassword")
   public ModelAndView forgot(HttpServletRequest request, Model m) {
		
		ModelAndView view = new ModelAndView();
		
		String opt = request.getParameter("rd");
		System.out.println(opt);
		String emailId = request.getParameter("emailid");
		String newpassword = request.getParameter("pwd");
		String confirmpassword = request.getParameter("cpwd");
		
		
		
		 if (opt.charAt(0) == 'm') {
				Merchant mer = merchantService.findByMerchantEmail(emailId);
		
			   if(mer==null) {
				   System.out.println("no merchant");
				   view.addObject("status1", "enter valid email account !!");
				   view.setViewName("forgotpassword");
			   }else {
				   if(newpassword.equals(confirmpassword)) {
			  
				    passwordService.changemerchantPassword(mer, newpassword);
				    view.addObject("status", "password changed succesfully!!!");
					   view.setViewName("forgotpassword");
				   }else {
					   view.addObject("status", "new password and confirm password should match");
					   view.setViewName("forgotpassword");
				   }
			   }

			   
		} else {
			Customer   c = customerService.findByEmailId(emailId);
			 System.out.println(c);
			   if(c==null) {
				   System.out.println("no customer");
				   view.addObject("status1", "enter valid email account !!");
				   view.setViewName("forgotpassword");
			   }else {
				   if(newpassword.equals(confirmpassword)) {
			  
				    passwordService.changecustomerPassword(c, newpassword);
				    view.addObject("status", "password changed succesfully!!!");
					   view.setViewName("forgotpassword");
				   }else {
					   view.addObject("status", "new password and confirm password should match");
					   view.setViewName("forgotpassword");
				   }
			   }

		}
		
		return view;
	}
	
	
	
	
}
