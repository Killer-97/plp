package com.capstore.boot.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.CustomerService;
import com.capstore.boot.service.MerchantService;


@Controller
public class AdminController {


	@Autowired
	CustomerService customerService;
	@Autowired
	MerchantService merchantService;

	
	
	@RequestMapping("/adminpage")
	public String adminpage() {
		return "adminpage";
	}
	
	
	@RequestMapping("/getUpdatePage")
	public ModelAndView updateCustomer(HttpServletRequest request) {
		
		ModelAndView view=new ModelAndView();
		
		String emailId = request.getParameter("customermail");
		Customer c=customerService.findByEmailId(emailId);
		
		view.addObject("customer",c);
		
		view.setViewName("UpdateCustomerform");
		
		return view;
	}
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("/CustomerPageForAdmin")
	public String showCustomerList(Model m){
		List<Customer> clist=customerService.getAllCustomers();
		m.addAttribute("cList", clist);
		return "CustomerPageForAdmin";
	}
	
	@RequestMapping("/MerchantPageForAdmin")
	public String showMerchantList(Model m,HttpServletRequest request){
		
		HttpSession session=request.getSession();
		
		List<Merchant> mlist=merchantService.getAllMerchant();
		session.setAttribute("merch", mlist);
		
		return "MerchantPageForAdmin";
	}
	
	@RequestMapping("/updateStatus")
	public ModelAndView update(HttpServletRequest request) {
		ModelAndView view=new ModelAndView();
		HttpSession session=request.getSession();
		
		List<Merchant> mlist=(List)session.getAttribute("merch");
		List<Integer> Idlist=new ArrayList<Integer>();
		System.out.println(mlist);
		for(Integer i=0;i<mlist.size();i++) {
			System.out.println(request.getParameter("sts"+i));
			if(request.getParameter("sts"+i)!=null) {
				Idlist.add(Integer.parseInt(request.getParameter("sts"+i)));
			}else {
				Idlist.add(-1);
			}
		}
		System.out.println(Idlist);
		for(int i=0;i<mlist.size();i++) {
			if(Idlist.get(i)!=-1) {
		Merchant m=merchantService.findMerchantById(Idlist.get(i));
		System.out.println(m);
		if(m.getStatus().equals("false")) {
		m.setStatus("true");
		}else {
			m.setStatus("false");
		}
		merchantService.saveMer(m);
			}
		}
		
		
		
		view.setViewName("redirect:/MerchantPageForAdmin");
		
		return view;
	}
	
	/*
	@RequestMapping("/updateStatus")
	public String update(HttpServletRequest request) {
		HttpSession session=request.getSession();
		List<Merchant> mlist=(List<Merchant>)session.getAttribute("merch");
		for(Merchant m1: mlist) {
			int Status=Integer.parseInt(request.getParameter("sts"));
			System.out.println(Status);
		}
		
		return "redirect:/Merchants";*/
	
	
	
	
	
	
	
	@RequestMapping("/Products")
	public String showProductList(Model m){
	/*	List<Inventory> list=customerService.getAllProducts();
		m.addAttribute("list", list);*/
		return "Products";
	}
	
	@RequestMapping("/coupon")
	public String showCoupon(Model m)
	{
		
		return "coupon";
	}
	@RequestMapping("/discount")
	public String showdiscount(Model m) {
		return "discount";
	}
	
	
	
	
	
	
}
