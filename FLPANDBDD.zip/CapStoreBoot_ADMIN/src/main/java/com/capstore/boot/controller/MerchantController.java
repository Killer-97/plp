package com.capstore.boot.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Address;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.MerchantService;

@Controller
public class MerchantController {

	
	@Autowired
	 MerchantService merchantService;
	
	@RequestMapping("/registerasmerchant")
	public String register() {
		return "merchantRegisterform";
	}
	
	
	@RequestMapping("/saveasmerchant")
	public ModelAndView addProduct(HttpServletRequest request) {
		
		ModelAndView modelView = new ModelAndView();
		
		Merchant merchant = new Merchant();
		Address address = new Address();
		
		String MerchantName = request.getParameter("mn");
		merchant.setMerchantname(MerchantName);
		
		String email = request.getParameter("memail");
		merchant.setEmailId(email);
		
		String password = request.getParameter("mpass");
		merchant.setPassword(password);
		
		String companyname = request.getParameter("cn");
		merchant.setCompanyName(companyname);
		
		String companyaddress = request.getParameter("ca");
		address.setZipcode(500072);
		address.setStreetNumber(12);
		List<Address> list1 =Arrays.asList(address);
		merchant.setAddress(list1);
		
		String phoneno = request.getParameter("pn");
		merchant.setPhoneNo(phoneno);
		
		String merchanttype=request.getParameter("mt");
		merchant.setIsCertified(merchanttype);

		merchant.setStatus("false");
		
		boolean status = merchantService.saveMerchant(merchant);
		
		if(status==true) {
			
			modelView.setViewName("home");
		}else {
			modelView.addObject("msg", "Merchant with this Email already exists!!");
			modelView.setViewName("merchantRegisterform");
		}
     	 
		return modelView;
	}
}
