package com.cg.mypaymentapp.service;

import java.math.BigDecimal;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.repo.WalletRepo;

/**
 * @author DMUKKAMA
 *
 */

@Service("walletService")
public class WalletServiceImpl implements WalletService {

	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Autowired
	WalletRepo walletRepo;

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileno, w);
		Customer c1 = new Customer();
		c1 = walletRepo.findByMobileNo(mobileno);
		if (c1 == null) {
			Customer status = walletRepo.save(c);
			return c;
		} else {
			return null;
		}

	}

	@Override
	public Customer showBalance(String mobileNo) {
		if (walletRepo.findByMobileNo(mobileNo) != null) {
			System.out.println("Customer balance is: " + walletRepo.findByMobileNo(mobileNo).getWallet().getBalance());
			return walletRepo.findByMobileNo(mobileNo);
		} else {
			return null;
		}

	}

	@Transactional
	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {

		if (walletRepo.findByMobileNo(sourceMobileNo) != null) {
			BigDecimal source = walletRepo.findByMobileNo(sourceMobileNo).getWallet().getBalance();
			if (walletRepo.findByMobileNo(targetMobileNo) != null) {
				BigDecimal target = walletRepo.findByMobileNo(sourceMobileNo).getWallet().getBalance();
				if (source == source.max(amount)) {

					source = source.subtract(amount);
					target = target.add(amount);
					Wallet w1 = walletRepo.findByMobileNo(sourceMobileNo).getWallet();
					Wallet w2 = walletRepo.findByMobileNo(targetMobileNo).getWallet();
					w1.setBalance(source);
					entityManager.merge(w1);
					w2.setBalance(target);
					entityManager.merge(w2);

					return walletRepo.findByMobileNo(targetMobileNo);

				}
			}
		} else {
			System.out.println("User does not exist");
			// return null;
		}
		return null;
	}

	@Transactional
	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		if (walletRepo.findByMobileNo(mobileNo) != null) {

			BigDecimal updatedAmount = walletRepo.findByMobileNo(mobileNo).getWallet().getBalance();
			updatedAmount = updatedAmount.add(amount);
			Wallet w = walletRepo.findByMobileNo(mobileNo).getWallet();
			w.setBalance(updatedAmount);
			entityManager.merge(w);
			return walletRepo.findByMobileNo(mobileNo);
		} else
			return null;
	}

	@Transactional
	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		if (walletRepo.findByMobileNo(mobileNo) != null) {
			BigDecimal updatedAmount = walletRepo.findByMobileNo(mobileNo).getWallet().getBalance();
			if (updatedAmount == updatedAmount.max(amount)) {
				updatedAmount = updatedAmount.subtract(amount);
				Wallet w = walletRepo.findByMobileNo(mobileNo).getWallet();
				w.setBalance(updatedAmount);
				entityManager.merge(w);
				return walletRepo.findByMobileNo(mobileNo);
			} else {
				return null;
			}
		} else
			return null;
	}

	public Customer findOne(String mobileNo) {
		// TODO Auto-generated method stub
		return walletRepo.findByMobileNo(mobileNo);
	}

}
