
package com.cg.mypaymentapp.repo;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.mypaymentapp.beans.Customer;

/**
 * @author DMUKKAMA
 *
 */
public interface WalletRepo extends JpaRepository<Customer, Integer> {



	public Customer findByMobileNo(String mobileNo);

	
}
