package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;

public class WalletServImpl implements WalletService {

	WalletRepo Repos;
	
	public WalletServImpl() {
		Repos = new WalletRepoImpl();
	}

	@Override
	public boolean createAccount(String name, String mobileno, BigDecimal amount) {
		
		Customer customer = new Customer();
		customer.setName(name);
		customer.setMobileNo(mobileno);

		Wallet wallet = new Wallet(amount);
		customer.setWallet(wallet);
		return Repos.save(customer);
	}

	@Override
	public Customer showBalance(String mobileno) {

		return Repos.findOne(mobileno);
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {

		return Repos.fundTransfer(sourceMobileNo, targetMobileNo, amount);
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {

		return Repos.depositAmount(mobileNo, amount);
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {

		return Repos.withdrawAmount(mobileNo, amount);
	}

}
