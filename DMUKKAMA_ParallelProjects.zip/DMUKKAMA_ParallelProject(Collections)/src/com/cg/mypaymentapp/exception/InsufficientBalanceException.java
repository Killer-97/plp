package com.cg.mypaymentapp.exception;

import java.math.BigDecimal;


/**
 * @author DMUKKAMA
 *
 */
public class InsufficientBalanceException {
 BigDecimal diff;
	public boolean checkBal(BigDecimal amount, BigDecimal target) {
	diff=target.max(amount);
		if(diff==target)
		{
			return true;
		}
		else
			return false;
	}

		
		
	

}
