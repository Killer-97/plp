package com.cg.mypaymentapp.exception;

/**
 * @author DMUKKAMA
 *
 */
public class InvalidInputException {

	
	public boolean checkNo(String mobileNo, String name) {
		if ( !((name.charAt(0) >= 'a' && name.charAt(0) <= 'z')
				|| (name.charAt(0) >= 'A' && name.charAt(0) <= 'Z'))) {
			System.out.println("Please, Enter the Valid name which should start with Alphabet");
			return false;
		}
		if (mobileNo.length()!= 10 ) {
			System.out.println("Please, Enter the valid 10 digit Number");
			return false;
		}
		else
		{
			return true;
		}

}
}