package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;

/**
 * @author DMUKKAMA
 *
 */

public class WalletRepoImpl implements WalletRepo {
	
	InsufficientBalanceException in = new InsufficientBalanceException();
    BigDecimal senderNewBal;
	BigDecimal recieverNewBal;
	boolean status = false;

	public WalletRepoImpl() {

	}

	Map<String, Customer> map = new HashMap<String, Customer>();

	@Override
	public boolean save(Customer customer) {
		if (!map.containsKey(customer.getMobileNo())) {
			map.put(customer.getMobileNo(), customer);
			System.out.println("Your Account is created successfully...");
		} else {
			System.out.println("This number already Exists..  add another number to save");
		}

		return false;
	}

	@Override
	public Customer findOne(String mobileNo) {
		if (map.containsKey(mobileNo)) {
			System.out.println(map.get(mobileNo).getWallet().getBalance());

		} else {
			System.out.println("This number does not exists... Please enter correct  number");
		}
		return null;
	}

	@Override
	public Customer fundTransfer(String sourceNo, String targetNo, BigDecimal Amount) {

		if (map.containsKey(targetNo) && map.containsKey(sourceNo)) {
			status = in.checkBal(Amount, map.get(targetNo).getWallet().getBalance());

			if (status) {

				senderNewBal = map.get(sourceNo).getWallet().getBalance();

				senderNewBal = senderNewBal.subtract(Amount);
				map.get(sourceNo).getWallet().setBalance(senderNewBal);
				recieverNewBal = map.get(targetNo).getWallet().getBalance();
				recieverNewBal = recieverNewBal.add(Amount);
				map.get(targetNo).getWallet().setBalance(recieverNewBal);
				System.out.println("Fund transfer is successful....");
				System.out.println(map.get(sourceNo).getWallet().getBalance() + " is your Balance in your Account");
				
			} else {
				System.out.println("Insufficient Balance to transfer the requested Amount");
			}
		} else {
			if (!map.containsKey(sourceNo) && map.containsKey(targetNo)) {
				System.out.println("Amount cannot be transfered to sender account as it's not found");

			}
			if (!map.containsKey(targetNo) && map.containsKey(sourceNo)) {
				System.out.println("Amount cannot be transferred receiver account as it's not found");
			}
			if (!map.containsKey(targetNo) && !map.containsKey(sourceNo)) {
				System.out.println("Amount cannot be transferred sender & receiver as both accounts not found");
			}

		}

		return null;
	}

	BigDecimal updatedBal;

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		if (map.containsKey(mobileNo)) {
			updatedBal = map.get(mobileNo).getWallet().getBalance();
			updatedBal = updatedBal.add(amount);
			map.get(mobileNo).getWallet().setBalance(updatedBal);
			System.out.println("AMOUNT IS DEPOSITED SUCCESFULLY");
			System.out.println(map.get(mobileNo).getName() + ", Your Current Balance is : " + updatedBal);
		} else {
			System.out.println("Sorry,Userdoes not exists");
		}
		return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		if (map.containsKey(mobileNo)) {
			updatedBal = map.get(mobileNo).getWallet().getBalance();
			updatedBal = updatedBal.subtract(amount);
			map.get(mobileNo).getWallet().setBalance(updatedBal);
			System.out.println("AMOUNT  WITHDRAWAL IS SUCCESFULLY");
			System.out.println(map.get(mobileNo).getName() + ", Your Current Balance is : " + updatedBal);
		} else {
			System.out.println("Sorry,User not Found.");
		}
		return null;
	}

}
