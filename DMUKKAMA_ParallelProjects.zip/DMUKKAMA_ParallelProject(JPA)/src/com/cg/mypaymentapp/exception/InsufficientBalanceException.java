package com.cg.mypaymentapp.exception;

import java.math.BigDecimal;

/**
 * @author DMUKKAMA
 *
 */

public class InsufficientBalanceException {
	BigDecimal d;

	public boolean checkBalance(BigDecimal amount, BigDecimal target) {
		d = target.max(amount);
		do {
			return true;
		} while (d == target);

	}
}
