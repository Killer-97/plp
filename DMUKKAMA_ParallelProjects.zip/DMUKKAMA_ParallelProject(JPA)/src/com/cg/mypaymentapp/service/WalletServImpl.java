package com.cg.mypaymentapp.service;

import java.math.BigDecimal;

import com.cg.mypaymentapp.Repo.WalletRepo;
import com.cg.mypaymentapp.Repo.WalletRepoImpl;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;

/**
 * @author DMUKKAMA
 *
 */

public class WalletServImpl implements WalletService {

	WalletRepo repo = new WalletRepoImpl();

	boolean status = false;

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		Customer customer = new Customer();
		Wallet wallet = new Wallet(amount);
		customer.setMobileNo(mobileno);
		customer.setName(name);
		customer.setWallet(wallet);
		status = repo.save(customer);
		return null;
	}

	@Override
	public Customer showBalance(String mobileno) {

		return repo.findOne(mobileno);
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {

		return repo.fundTransfer(sourceMobileNo, targetMobileNo, amount);
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {

		return repo.depositAmount(mobileNo, amount);
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {

		return repo.withdrawAmount(mobileNo, amount);
	}

}
