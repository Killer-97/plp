package com.cg.mypaymentapp.ui;

import java.math.BigDecimal;
import java.util.Scanner;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletServImpl;
import com.cg.mypaymentapp.service.WalletService;

/**
 * @author DMUKKAMA
 *
 */
public class MainUi {

	public static void main(String[] args) {
		WalletService service = new WalletServImpl();
		InvalidInputException input = new InvalidInputException();

		String name, mobileNumber;
		String senderNo, recvNo;
		BigDecimal amount;

		System.out.println("================ Welcome to MyPayment App ===============");
		System.out.println("\n\n");
		Scanner sc = new Scanner(System.in);

		char option = 'n';
		do {
			System.out.println("Enter the choice to peform operations\n");
			System.out.println("******************************************************************************");
			System.out.println(
					"1.create Account \n2.Show Account\n3.Fund Transfer\n4.Deposit into the Account\n5.WithDraw from the Account\n6.Exit");
			System.out.println("******************************************************************************");
			int choice = sc.nextInt();
			boolean status = false;
			switch (choice) {
			case 1:
				System.out.println("Enter the name of the User");
				name = sc.next();
				System.out.println("Enter the Mobile no:");
				mobileNumber = sc.next();
				System.out.println("Enter the Balance amount:");
				amount = sc.nextBigDecimal();
				service.createAccount(name, mobileNumber, amount);

				break;

			case 2:

				System.out.println("Enter the mobile no to view Balance");
				mobileNumber = sc.next();
				service.showBalance(mobileNumber);
				break;

			case 3:
				System.out.println("Enter the Sender mobileNo:");
				senderNo = sc.next();
				System.out.println("Enter the Recipient mobileNo:");
				recvNo = sc.next();
				System.out.println("Enter amount to be Transferred: ");
				amount = sc.nextBigDecimal();

				service.fundTransfer(senderNo, recvNo, amount);
				break;

			case 4:
				System.out.println("Enter your mobile no:");
				mobileNumber = sc.next();
				System.out.println("Enter the amount to be added:");
				amount = sc.nextBigDecimal();
				service.depositAmount(mobileNumber, amount);
				break;
			case 5:
				System.out.println("Enter your mobile no:");
				mobileNumber = sc.next();
				System.out.println("Enter the amount to WithDraw:");
				amount = sc.nextBigDecimal();
				service.withdrawAmount(mobileNumber, amount);
				break;

			case 6:
				System.exit(0);
				break;

			default:
				System.out.println("enter correct option ");
				break;
			}
			System.out.println("Press (y/Y) to continue: \n");
			option = sc.next().charAt(0);

		} while (option == 'y' || option == 'Y');

	}

}
