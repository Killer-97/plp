package com.cg.mypaymentapp.Repo;

import java.math.BigDecimal;

import com.cg.mypaymentapp.beans.Customer;

/**
 * @author DMUKKAMA
 *
 */
public interface WalletRepo {
	
	public boolean save(Customer customer);

	public Customer findOne(String mobileNo);

	public Customer fundTransfer(String sourceNo, String targetNo, BigDecimal Amount);

	public Customer depositAmount(String mobileNo, BigDecimal amount);

	public Customer withdrawAmount(String mobileNo, BigDecimal amount);

}
