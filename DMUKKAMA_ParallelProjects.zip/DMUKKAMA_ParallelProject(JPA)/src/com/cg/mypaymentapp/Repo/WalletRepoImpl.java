package com.cg.mypaymentapp.Repo;

import java.math.BigDecimal;

import java.util.HashMap;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;

public class WalletRepoImpl implements WalletRepo {
	InsufficientBalanceException ibe = new InsufficientBalanceException();
	EntityManager em = null;
	Customer c, c1;
	Wallet w, w1;
	Map<String, Customer> map = new HashMap<String, Customer>();

	BigDecimal withdraw, rec, res, dep;
	String recname, sendname;

	@Override
	public boolean save(Customer customer) {

		em = MyEntityManager.getEntityManager();
		EntityTransaction tr = em.getTransaction();
		tr.begin();
		em.persist(customer);
		tr.commit();
		return true;
	}

	@Override
	public Customer findOne(String mobileNo) {
		em = MyEntityManager.getEntityManager();
		EntityTransaction tr = em.getTransaction();
		tr.begin();
		Query q = em.createQuery("from Customer c where c.mobileNo=?1 ");
		q.setParameter(1, mobileNo);

		Customer c = (Customer) q.getSingleResult();
		System.out.println(c.getWallet().getBalance());
		tr.commit();
		return null;
	}

	BigDecimal senderUpdatedBal, recvUpdatedBal, snBal, rcBal;
	boolean status = false;

	@Override
	public Customer fundTransfer(String sourceNo, String targetNo, BigDecimal Amount) {
		em = MyEntityManager.getEntityManager();
		EntityTransaction tr = em.getTransaction();
		tr.begin();
		Query q1 = em.createQuery("from Customer c where c.mobileNo=?1 ");
		Query q2 = em.createQuery("from Customer c where c.mobileNo=?2");
		q1.setParameter(1, sourceNo);
		q2.setParameter(2, targetNo);
		c = (Customer) q1.getSingleResult();
		c1 = (Customer) q2.getSingleResult();
		w = em.find(Wallet.class, c.getWallet().getWalletid());
		w1 = em.find(Wallet.class, c1.getWallet().getWalletid());
		snBal = w.getBalance();
		senderUpdatedBal = snBal.subtract(Amount);
		w.setBalance(senderUpdatedBal);
		rcBal = w.getBalance();
		recvUpdatedBal = rcBal.add(Amount);
		w1.setBalance(recvUpdatedBal);
		tr.commit();
		rec = w1.getBalance();
		res = w1.getBalance();
		sendname = c.getName();
		recname = c1.getName();
		System.out.println("Amount : " + Amount + " transferred from " + c.getName() + " to " + c1.getName());
		return null;
	}

	BigDecimal updateBal, Balance;
	int id;

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		em = MyEntityManager.getEntityManager();
		EntityTransaction tr = em.getTransaction();
		tr.begin();
		Query q = em.createQuery("from Customer c where c.mobileNo=?1");
		q.setParameter(1, mobileNo);

		c = (Customer) q.getSingleResult();
		w = em.find(Wallet.class, c.getWallet().getWalletid());
		Balance = w.getBalance();
		updateBal = Balance.add(amount);
		w.setBalance(updateBal);
		tr.commit();
		dep = w.getBalance();
		System.out.println("Your Balance is Updated. Your new balance is " + w.getBalance());

		return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		em = MyEntityManager.getEntityManager();
		EntityTransaction tr = em.getTransaction();
		tr.begin();
		Query q = em.createQuery("from Customer c where c.mobileNo=?1");
		q.setParameter(1, mobileNo);
		c = (Customer) q.getSingleResult();
		w = em.find(Wallet.class, c.getWallet().getWalletid());
		Balance = w.getBalance();
		updateBal = Balance.subtract(amount);
		w.setBalance(updateBal);
		tr.commit();
		withdraw = w.getBalance();
		System.out.println("Your Balance is Updated.  Your new balance is " + w.getBalance());
		return null;
	}

}
