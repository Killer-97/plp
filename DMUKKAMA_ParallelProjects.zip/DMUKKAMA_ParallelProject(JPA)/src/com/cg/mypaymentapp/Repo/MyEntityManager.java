package com.cg.mypaymentapp.Repo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * @author DMUKKAMA
 *
 */
public class MyEntityManager {
	static EntityManager em = null;

	public static EntityManager getEntityManager() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
		em = emf.createEntityManager();
		return em;
	}
}
