package com.cg.mypaymentapp.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author DMUKKAMA
 *
 */

@Entity
@Table(name = "Wallet_Detail")
public class Wallet implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wall")
	@SequenceGenerator(name = "wall", sequenceName = "sa2", initialValue = 110, allocationSize = 1)
	private int walletid;
	private BigDecimal balance;

	public Wallet() {
		super();

	}

	public Wallet(BigDecimal balance) {

		this.balance = balance;
	}

	public void setWalletid(int walletid) {
		this.walletid = walletid;
	}

	public int getWalletid() {
		return walletid;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {

		return "balance=" + balance;
	}
}
