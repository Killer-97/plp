
package com.cg.mypaymentapp.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.service.WalletService;


@RestController
@RequestMapping("/prorest")
public class MyController {
	@Autowired
	WalletService walletService;

	Customer customer=null,customer1=null;
	
	@GetMapping("/create/{name}/{mobileNo}/{balance}")
	public Customer create(@PathVariable("name") String name,@PathVariable("mobileNo") String mobile,@PathVariable("balance") BigDecimal balance)
	{
		
		Customer c=walletService.createAccount(name,mobile,balance);
		return c;
	}
	
	@GetMapping("/login/{mobileNo}")
	public String login(@PathVariable("mobileNo") String mobileNo) {
	
		customer = walletService.findOne(mobileNo);
		if(customer!=null)
		return "Hello "+customer.getName()+"your Login is successful";
		else
		return "Invalid mobile number.Please enter valid mobile number";	
	}
	
	@GetMapping("/showbalance/{mobileNo}")
	public String showbalance(@PathVariable("mobileNo") String mobileNo)
	{
		customer = walletService.findOne(mobileNo);
		if(customer!=null)
		{
			customer=walletService.showBalance(mobileNo);
		    return "Dear "+customer.getName()+" Your Balance is "+customer.getWallet().getBalance();
		}
		else
		return null;
	}
	
	@GetMapping("/fundtransfer/{sourcemobileNo}/{targetmobileNo}/{balance}")
	public String fundtransfer(@PathVariable("sourcemobileNo") String sourcemobileNo,@PathVariable("targetmobileNo") String targetmobileNo,@PathVariable("balance") BigDecimal amount)
	{
		customer = walletService.findOne(sourcemobileNo);
		customer1 = walletService.findOne(targetmobileNo);
		if(customer!=null&&customer1!=null)
		{
		BigDecimal walletbal1 = customer.getWallet().getBalance();
		int res=walletbal1.compareTo(amount);
		if(res==1)
		{
		Customer c=walletService.fundTransfer(sourcemobileNo,targetmobileNo,amount);
		return "Fund transfer is successful\n"+"fund from "+sourcemobileNo+" to "+targetmobileNo;
		}
		else
		{
	        return "Insufficient balance.Add amount for right fund transfer";
		}
		}
		else
		{
			return "Sender's or reciever's mobile number does not exists";
		}
	}
	@GetMapping("/deposit/{mobileNo}/{amount}")
	public  String  deposit(@PathVariable("mobileNo") String mobileNo,@PathVariable("amount") BigDecimal amount)
	{
	
		customer = walletService.findOne(mobileNo);
		
		if(customer!=null)
		{
		customer=walletService.depositAmount(mobileNo, amount);
		return "Amount "+amount+" is successfully deposited";
		}
		else
		{
			return "Invalid mobile number.Please enter th evalid mobile number";
		}
	}

	@GetMapping("/withdraw/{mobileNo}/{amount}")
	public String withdraw(@PathVariable("mobileNo") String mobileNo,@PathVariable("amount") BigDecimal amount)
	{
		customer = walletService.findOne(mobileNo);
		
		
		if(customer!=null)
		{
		BigDecimal walletbal1 = customer.getWallet().getBalance();
		int res=walletbal1.compareTo(amount);
		if(res==1)
		{
			customer=walletService.withdrawAmount(mobileNo, amount);
			return "Amount "+amount+" is successfully withdrawn";
		}
		else
		{
			return  "Insufficient balance";
		}
		}
		else
		{
			return "Invalid mobile number and add valid mobile number";
		}
	}

	
}
