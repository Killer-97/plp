package com.cg.mypaymentapp.exception;

import java.math.BigDecimal;

public class InsufficientBalanceException extends RuntimeException{

	public InsufficientBalanceException(String msg) {
		super(msg);
	}
	
}
