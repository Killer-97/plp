package com.cg.mypaymentapp.repo;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.cg.mypaymentapp.beans.Customer;

/**
 * @author DMUKKAMA
 *
 */

/**
 * Lib folder which contains all libraries for this project has been deleted due to folder size issue to upload for the assignment..
 *
 */

@Repository("walletRepo")
public class WalletRepoImpl implements WalletRepo {

	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Transactional
	@Override
	public boolean save(Customer customer) {

		entityManager.persist(customer);
		return true;

	}

	@Override
	public Customer findOne(String mobileNo) {

		Customer customer = null;
		Query q = entityManager.createQuery("from Customer where mobileNo=?1");
		q.setParameter(1, mobileNo);
		q.setMaxResults(1);
		List<Customer> custlist = q.getResultList();
		if (custlist.size() > 0) {
			customer = custlist.get(0);
		}
		if (customer != null) {
			return customer;
		} else {
			return null;
		}
	}
}
