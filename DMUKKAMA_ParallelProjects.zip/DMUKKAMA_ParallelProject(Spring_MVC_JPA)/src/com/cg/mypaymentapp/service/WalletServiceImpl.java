package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.repo.WalletRepo;

/**
 * @author DMUKKAMA
 *
 */


/**
 * Lib folder which contains all libraries for this project has been deleted due to folder size issue to upload for the assignment..
 *
 */

@Service("walletService")
public class WalletServiceImpl implements WalletService {

	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Autowired
	WalletRepo walletRepo;

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileno, w);
		Customer c1 = new Customer();
		c1 = walletRepo.findOne(mobileno);
		if (c1 == null) {
			boolean status = walletRepo.save(c);
			return c;
		} else {
			return null;
		}

	}

	@Override
	public Customer showBalance(String mobileNo) {
		if (walletRepo.findOne(mobileNo) != null) {
			System.out.println("Customer balance is: " + walletRepo.findOne(mobileNo).getWallet().getBalance());
			return walletRepo.findOne(mobileNo);
		} else {
			return null;
		}

	}

	@Transactional
	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {

		if (walletRepo.findOne(sourceMobileNo) != null) {
			BigDecimal source = walletRepo.findOne(sourceMobileNo).getWallet().getBalance();
			if (walletRepo.findOne(targetMobileNo) != null) {
				BigDecimal target = walletRepo.findOne(sourceMobileNo).getWallet().getBalance();
				if (source == source.max(amount)) {

					source = source.subtract(amount);
					target = target.add(amount);
					Wallet w1 = walletRepo.findOne(sourceMobileNo).getWallet();
					Wallet w2 = walletRepo.findOne(targetMobileNo).getWallet();
					w1.setBalance(source);
					entityManager.merge(w1);
					w2.setBalance(target);
					entityManager.merge(w2);

					return walletRepo.findOne(targetMobileNo);

				}
			}
		} else {
			System.out.println("User does not exist");
		
		}
		return null;
	}

	@Transactional
	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		if (walletRepo.findOne(mobileNo) != null) {

			BigDecimal updatedAmount = walletRepo.findOne(mobileNo).getWallet().getBalance();
			updatedAmount = updatedAmount.add(amount);
			Wallet w = walletRepo.findOne(mobileNo).getWallet();
			w.setBalance(updatedAmount);
			entityManager.merge(w);
			return walletRepo.findOne(mobileNo);
		} else
			return null;
	}

	@Transactional
	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		if (walletRepo.findOne(mobileNo) != null) {
			BigDecimal updatedAmount = walletRepo.findOne(mobileNo).getWallet().getBalance();
			if (updatedAmount == updatedAmount.max(amount)) {
				updatedAmount = updatedAmount.subtract(amount);
				Wallet w = walletRepo.findOne(mobileNo).getWallet();
				w.setBalance(updatedAmount);
				entityManager.merge(w);
				return walletRepo.findOne(mobileNo);
			} else {
				return null;
			}
		} else
			return null;
	}

	public Customer findOne(String mobileNo) {
		
		return walletRepo.findOne(mobileNo);
	}

}
