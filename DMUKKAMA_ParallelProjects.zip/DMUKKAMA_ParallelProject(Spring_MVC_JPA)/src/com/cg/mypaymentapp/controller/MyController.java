
package com.cg.mypaymentapp.controller;

import java.math.BigDecimal;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.service.WalletService;

/**
 * @author DMUKKAMA
 *
 */

/**
 * Lib folder which contains all libraries for this project has been deleted due to folder size issue to upload for the assignment..
 *
 */

@Controller
public class MyController {
	@Autowired
	WalletService walletService;

	@RequestMapping("/loginpage")
	public String login() {
		return "login";
	}

	@RequestMapping("/login")
	public ModelAndView login(HttpServletRequest request) {
		ModelAndView andView = new ModelAndView();
		String mobileno = request.getParameter("mobileno");
		Customer c = walletService.findOne(mobileno);
		if (c != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", c);
			andView.setViewName("myhome");
		} else {
			andView.setViewName("login");
			andView.addObject("status", "User doesnot exist");
		}
		return andView;
	}

	@RequestMapping("/registerform")
	public String register() {
		return "registerform";
	}

	@RequestMapping("/register")
	public ModelAndView register(HttpServletRequest request) {
		ModelAndView andview = new ModelAndView();
		String name = request.getParameter("name");
		String mobileno = request.getParameter("mobileno");
		BigDecimal amount = new BigDecimal(request.getParameter("balance"));
		Customer c = walletService.createAccount(name, mobileno, amount);
		if (c != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", c);
			andview.addObject("status", "Registered Successfully!!!!");
			andview.setViewName("registerconfirm");
		} else {
			andview.addObject("status", "mobile number already exists!!!!");
			andview.setViewName("registerconfirm");

		}
		return andview;
	}

	@RequestMapping("/showbalanceform")
	public ModelAndView showbalance(HttpServletRequest request) {
		ModelAndView andview = new ModelAndView();
		HttpSession session = request.getSession();
		Customer cus = (Customer) session.getAttribute("user");
		Customer c = walletService.showBalance(cus.getMobileNo());
		andview.setViewName("showbalanceform");
		if (c != null) {
			session = request.getSession();
			session.setAttribute("user", c);
		}
		return andview;
	}

	@RequestMapping("/myhome")
	public String myhomepage() {
		return "myhome";
	}

	@RequestMapping("/fundtransferform")
	public String fund() {
		return "fundtransferform";
	}

	@RequestMapping("/fundtransfer")
	public ModelAndView fundtrasfer(HttpServletRequest request) {
		ModelAndView andview = new ModelAndView();
		String target = request.getParameter("mobileno");
		HttpSession session = request.getSession();
		Customer cus = (Customer) session.getAttribute("user");
		BigDecimal amount = new BigDecimal(request.getParameter("amount"));
		Customer c = walletService.fundTransfer(cus.getMobileNo(), target, amount);
		if (c != null) {
			andview.addObject("msg", "fund transfered to " + target);
			andview.setViewName("fundtransferform");
		} else {
			andview.addObject("msg", "invalid mobileno");
			andview.setViewName("fundtransferform");
		}
		return andview;
	}

	@RequestMapping("/depositform")
	public String depositform() {
		return "depositform";
	}

	@RequestMapping("/deposit")
	public ModelAndView deposit(HttpServletRequest request) {
		ModelAndView andView = new ModelAndView();
		BigDecimal amount = new BigDecimal(request.getParameter("amount"));
		HttpSession session = request.getSession();
		Customer cus = (Customer) session.getAttribute("user");
		Customer c = walletService.depositAmount(cus.getMobileNo(), amount);
		if (c != null) {
			andView.addObject("msg", "Fund Successfully deposited.....");
			andView.setViewName("depositform");
		}

		return andView;
	}

	@RequestMapping("/withdrawform")
	public String withdrawform() {
		return "withdrawform";
	}

	@RequestMapping("/withdraw")
	public ModelAndView withdraw(HttpServletRequest request) {
		ModelAndView andview = new ModelAndView();
		HttpSession session = request.getSession();
		BigDecimal amount = new BigDecimal(request.getParameter("amount"));
		Customer cus = (Customer) session.getAttribute("user");
		Customer c = walletService.withdrawAmount(cus.getMobileNo(), amount);
		if (c != null) {
			andview.addObject("msg", "Amount is withdrawn from your account");
			andview.setViewName("withdrawform");
		} else {
			andview.addObject("msg", "The money in your account is not enough to make this transaction ");
			andview.setViewName("withdrawform");
		}
		return andview;
	}

}
