package com.capstore.boot.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.hibernate.query.criteria.internal.predicate.BetweenPredicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.FeedBack;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.service.IFeedbackService;
import com.capstore.boot.service.InventoryService;


@Controller
public class CapStoreController 
{
	@Autowired
	InventoryService inventoryService;
	
	@Autowired
	IFeedbackService iFeedbackService;
	
	@RequestMapping(value="all")
	public String start()
	{
		return "home";
		
	}
	

	@RequestMapping(value="login")
	public ModelAndView showlogin(Model model){
		return new ModelAndView("login");
	}
	
	
	@RequestMapping(value="/")
	public ModelAndView home(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		
		HttpSession session = request.getSession();
		
		List<Inventory> productlist = inventoryService.getAll();
		
		modelView.addObject("plist", productlist);
		
		session.setAttribute("prodlist", productlist);
//		System.out.println(productlist.get(0).getDiscount().getDiscountPercent());
		System.out.println(productlist.get(5).getMerchant().getMerchantname());
		System.out.println(productlist);
		
		modelView.setViewName("home");
		return modelView;
	}

	
	
	
	@RequestMapping(value="/search")
	public ModelAndView search(HttpServletRequest request , @RequestParam("sss") String name) {
		
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		
		
		
		List<Inventory> productlist = inventoryService.getInventoryByName(name);
		
		session.setAttribute("prodlist", productlist);

		Customer  c = (Customer)session.getAttribute("user");
		if(c!=null) {
			modelView.setViewName("home1");
		}else {
		modelView.setViewName("home");
		}
		return modelView;
	}
	
	@RequestMapping(value="/str")
	public ModelAndView sort(HttpServletRequest request , @RequestParam("p") String option) {
		
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		
		List<Inventory> list =  (List<Inventory>) session.getAttribute("prodlist");
	
		if(option.equals("noofviews")) {
			Comparator<Inventory> comp  = (i1, i2) -> Double.compare(i2.getNoOfViews(),i1.getNoOfViews());
			Collections.sort(list , comp);
		}else if(option.equals("lowtohigh")){
			Comparator<Inventory> comp  = (i1, i2) -> Double.compare(i1.getPrice(),i2.getPrice());
			Collections.sort(list , comp);
		}else{
			Comparator<Inventory> comp  = (i1, i2) -> Double.compare(i2.getPrice(),i1.getPrice());
			Collections.sort(list , comp);
		}
		
		Customer  c = (Customer)session.getAttribute("user");
		if(c!=null) {
			modelView.setViewName("home1");
		}else {
		modelView.setViewName("home");
		}
		return modelView;
	}
	
	
	   @RequestMapping(value="/sortbyrange")
		public ModelAndView sort(HttpServletRequest request) {
			ModelAndView modelView = new ModelAndView();
			HttpSession session = request.getSession();
			List<Inventory> list =  (List<Inventory>) session.getAttribute("prodlist");
			
			List<Inventory> priceRangeList = new ArrayList<>();
			
			 double min = Double.parseDouble(request.getParameter("min"));
			 double max = Double.parseDouble(request.getParameter("max"));
			
			 for(Inventory i : list) {

					if( ( (i.getPrice()) >= min) && ((i.getPrice()) <= max) ) {
						priceRangeList.add(i);
					}
				}
			session.setAttribute("prodlist", priceRangeList);
			Customer  c = (Customer)session.getAttribute("user");
			if(c!=null) {
				modelView.setViewName("home1");
			}else {
			modelView.setViewName("home");
			}
			
			return modelView;
		}
	  
	
	
		
	   @RequestMapping(value="/productdisplay")
	   public ModelAndView productDisplay(HttpServletRequest request,@RequestParam("productid") int pid) {
	   	ModelAndView modelView = new ModelAndView();
	   	HttpSession session = request.getSession();
	   	

	   	Inventory i=inventoryService.getProductByid(pid);
	   	i.setNoOfViews(i.getNoOfViews());
	   	inventoryService.save1(i);
	   	session.setAttribute("product", i);
	   	
	   	System.out.println(i);
	   	
	   	List<FeedBack> feedback = iFeedbackService.getAll(pid);
	   	
	   	session.setAttribute("feedbacklist", feedback); 
	   	
	   
	   	 
	   	  int mid = i.getMerchant().getMerchantId();
	   	  System.out.println(i);
	   	  double avgrating=iFeedbackService.avgrating(pid);
	   	  
	   	  session.setAttribute("average",avgrating);
	   	  
	   	  double merchantrating=iFeedbackService.merchantrating(mid);
	   	  
	   	  session.setAttribute("mrechantaverage",merchantrating);
	   	modelView.setViewName("productPage");
	   	
	   	return modelView;
	   }
	   	
	   	
	  /* 	@RequestMapping(value="products?id=10")
	   	public ModelAndView showData(Model model){
	   		List<Inventory> allElectronics= service.showAllElectronics();
	   		model.addAttribute("Mobiles");
	   		
	   		return new ModelAndView("Electronicproducts");
	   		
	   	}
	   	*/
	   

	   
     @RequestMapping("/cartdisplay")
 	public ModelAndView cartDisplay(HttpServletRequest request) {
    	 
     
			ModelAndView modelView = new ModelAndView();
			HttpSession session = request.getSession();
			
			Customer  c = (Customer)session.getAttribute("user");
			
			
			if(c==null) {
					modelView.setViewName("login");
			}else {
				
			}
			return modelView;
     }
     
     @RequestMapping("/wishlistdisplay")
  	public ModelAndView wishlistdisplay(HttpServletRequest request) {
     	 
      
 			ModelAndView modelView = new ModelAndView();
 			HttpSession session = request.getSession();
 			
 			Customer  c = (Customer)session.getAttribute("user");
 			
 			
 			if(c==null) {
 					modelView.setViewName("login");
 			}else {
 				
 			}
 			return modelView;
      }
 }
	
	
	
	


