package com.capstore.boot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Category;

import com.capstore.boot.model.Inventory;



@Repository("categoryDao")
public interface CategoryDao extends JpaRepository<Category, Integer> {

	List<Inventory> findAllBycategoryName(String name);
}
