package com.capstore.boot.dao;

import java.util.List;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;

@Repository("inventoryDao")


public interface InventoryDao extends JpaRepository<Inventory, Integer>{
	
	@Query("select i from Inventory i where i.productName=:product")
	Inventory findOne(@Param("product") String product);
	
	List<Inventory> findByproductName(String name);

	List<Inventory> findByMerchant(Merchant merchant);
	
	 @Query("select a FROM Inventory a WHERE a.merchant.merchantId=:merchantId")
	List<Inventory> findBymerchantId( @Param("merchantId")Integer  merchantId);
	

}
