package com.cg.capstore.controller;

import javax.servlet.http.HttpServletRequest;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.service.CustomerService;
import com.cg.capstore.service.MerchantService;

@Controller
public class MerchantController {
	@Autowired
	 MerchantService merchantService;
	
	@RequestMapping("/merchantRegister")
	public String merchantRegister() {
		return "merchantRegister";
	}
	
	
	@RequestMapping("/save")
	public String addProduct(HttpServletRequest request) {
		String MerchantName = request.getParameter("mn");
		String email = request.getParameter("memail");
		String password = request.getParameter("mpass");
		String companyname = request.getParameter("cn");
		String companyaddress = request.getParameter("ca");
		String phoneno = request.getParameter("pn");
		String merchanttype=request.getParameter("mt");
        merchantService.createMerchantAccount(MerchantName, email, password, companyname, companyaddress, phoneno, merchanttype,0,"");
		return "home";
	}
	@RequestMapping("/checkorders")
	public String checkorders() {
		return "checkorders";
	}
	@RequestMapping("/addproduct")
	public String addproduct() {
		return "addproduct";
	}
	@RequestMapping("/deleteproduct")
	public String deleteproduct() {
		return "deleteproduct";
	}
	@RequestMapping("/newpromos")
	public String newpromos() {
		return "newpromosr";
	}
	@RequestMapping("/discountrates")
	public String discountrates() {
		return "discountrates";
	}
	@RequestMapping("/MerchantHome")
	public String MerchantHome() {
		return "MerchantHome";
	}
	@RequestMapping("/M_index")
	public String M_index() {
		return "M_index";
	}
	@RequestMapping("/M_Add_Merchant")
	public String M_Add_Merchant() {
		return "M_Add_Merchant";
	}
	@RequestMapping("/M_allProdsOfThirdParty")
	public String M_allProdsOfThirdParty() {
		return "M_allProdsOfThirdParty";
	}
	@RequestMapping("/M_Delete_Merchant")
	public String M_Delete_Merchant() {
		return "M_Delete_Merchant";
	}
	@RequestMapping("M_showAll")
	public String M_showAll() {
		return "M_showAll";
	}
	@RequestMapping("/M_showAllThirdParty")
	public String M_showAllThirdParty() {
		return "M_showAllThirdParty";
	}
	

}
