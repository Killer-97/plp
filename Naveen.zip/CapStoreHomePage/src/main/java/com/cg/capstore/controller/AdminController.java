package com.cg.capstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Merchant;
import com.cg.capstore.service.CustomerService;
import com.cg.capstore.service.MerchantService;


@Controller
public class AdminController {


	@Autowired
	CustomerService customerService;
	@Autowired
	MerchantService merchantService;

	@RequestMapping("/adminpage")
	public String adminpage() {
		return "adminpage";
	}
	
	
	@RequestMapping("/getUpdatePage")
	public ModelAndView updateCustomer(HttpServletRequest request) {
		
		ModelAndView view=new ModelAndView();
		
		String emailId = request.getParameter("email");
		Customer c=customerService.findByEmailId(emailId);
		
		view.addObject("customer",c);
		return view;
	}
	
	@RequestMapping("/Customers")
	public String showCustomerList(Model m){
		List<Customer> clist=customerService.getAllCustomers();
		m.addAttribute("cList", clist);
		return "Customers";
	}
	
	@RequestMapping("/Merchants")
	public String showMerchantList(Model m){
		List<Merchant> mlist=customerService.getAllMerchants();
		m.addAttribute("mList", mlist);
		return "Merchants";
	}
	
	@RequestMapping("/Products")
	public String showProductList(Model m){
	/*	List<Inventory> list=customerService.getAllProducts();
		m.addAttribute("list", list);*/
		return "Products";
	}
	
	@RequestMapping("/coupon")
	public String showCoupon(Model m)
	{
		
		return "coupon";
	}
	@RequestMapping("/discount")
	public String showdiscount(Model m) {
		return "discount";
	}
	
	
	
	
	
	
}
