package com.cg.capstore.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.CustomerRepository;
import com.cg.capstore.dao.MerchantRepository;
import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Inventory;
import com.cg.capstore.dto.Merchant;
@Service("customerService")
public class CustomerServiceimpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	MerchantRepository merchantRepository;
	
	@Override
	public Customer createAccount(String firstName, String lastName, String phoneNo, String emailId, String password) {
		
		Customer c=new Customer(firstName, lastName, phoneNo, emailId,  password);
		
		customerRepository.save(c);
		return c;
	}
	@Override
	public Customer findByEmailId(String emailId) {
		
		return customerRepository.findByEmailId(emailId);
	}
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}
	@Override
	public List<Merchant> getAllMerchants() {
		// TODO Auto-generated method stub
		return merchantRepository.findAll();
	}
	@Override
	public List<Inventory> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
