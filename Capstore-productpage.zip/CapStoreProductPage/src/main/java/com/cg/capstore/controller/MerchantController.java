package com.cg.capstore.controller;

import javax.servlet.http.HttpServletRequest;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.service.CustomerService;
import com.cg.capstore.service.MerchantService;

@Controller("merchantController")
public class MerchantController {
	@Autowired
	 MerchantService merchantService;
	
	@RequestMapping("/registerasmerchant")
	public String register() {
		return "merchantRegisterform";
	}
	
	
	@RequestMapping("/saveasmerchant")
	public String addProduct(HttpServletRequest request) {
		String MerchantName = request.getParameter("mn");
		String email = request.getParameter("memail");
		String password = request.getParameter("mpass");
		String companyname = request.getParameter("cn");
		String companyaddress = request.getParameter("ca");
		String phoneno = request.getParameter("pn");
		String merchanttype=request.getParameter("mt");

		
	
		merchantService.createMerchantAccount(MerchantName, email, password, companyname, companyaddress, phoneno, merchanttype,0,"");
		return "home";
	}
}
