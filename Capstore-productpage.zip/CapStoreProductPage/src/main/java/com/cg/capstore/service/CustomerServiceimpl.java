package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.CustomerRepository;
import com.cg.capstore.dto.Customer;
@Service("customerService")
public class CustomerServiceimpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	@Override
	public Customer createAccount(String firstName, String lastName, String phoneNo, String emailId, String password) {
		
		Customer c=new Customer(firstName, lastName, phoneNo, emailId,  password);
		
		customerRepository.save(c);
		return c;
	}
	@Override
	public Customer findByEmailId(String emailId) {
		
		return customerRepository.findByEmailId(emailId);
	}

}
