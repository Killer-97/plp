package com.cg.capstore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.CodePointLength;
import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name="Merchant_details")
public class Merchant {
	
	@Id
	@GeneratedValue(generator="plp1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="plp1",sequenceName="plp1",initialValue=1,allocationSize=1)
	@Column(name="merchant_Id")
	private int merchantId;

	private String merchantname;
	
	@Column(name="email_id",unique=true)
	private String merchantEmail; 
	
	private String password;
	
	private String Companyname;
	
	private String CompanyAddress;
	
	private String phone_no;
	
	private String merchantType;
	
	private int flag; 
	
	private String rating;
	public Merchant() {
		// TODO Auto-generated constructor stub
	}
	
	public Merchant(String merchantname, String merchantEmail, String password, String companyname,
			String companyAddress, String phone_no, String merchantType, int flag, String rating) {
		super();
		this.merchantname = merchantname;
		this.merchantEmail = merchantEmail;
		this.password = password;
		Companyname = companyname;
		CompanyAddress = companyAddress;
		this.phone_no = phone_no;
		this.merchantType = merchantType;
		this.flag = flag;
		this.rating = rating;
	}

	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantname() {
		return merchantname;
	}
	public void setMerchantname(String merchantname) {
		this.merchantname = merchantname;
	}
	public String getMerchantEmail() {
		return merchantEmail;
	}
	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompanyname() {
		return Companyname;
	}
	public void setCompanyname(String companyname) {
		Companyname = companyname;
	}
	public String getCompanyAddress() {
		return CompanyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		CompanyAddress = companyAddress;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", merchantname=" + merchantname + ", MerchantEmail="
				+ merchantEmail + ", password=" + password + ", Companyname=" + Companyname + ", CompanyAddress="
				+ CompanyAddress + ", phone_no=" + phone_no + ", merchantType=" + merchantType +  
				 ", flag=" + flag + ", rating=" + rating + "]";
	}

}
